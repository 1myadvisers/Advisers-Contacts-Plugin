# Advisers Contacts — Developer Documentation

This document covers the plugin's architecture, database schema, every
action/filter it exposes, and its multisite behavior. It's aimed at
developers extending or auditing the plugin, not end users (see
`readme.txt` for that).

## Requirements

- WordPress 6.4+
- PHP 7.4+
- MySQL/MariaDB as bundled with WordPress core (uses `$wpdb`/`dbDelta()` only)

## Architecture

All classes are prefixed `AC_` and autoloaded from `includes/` by the
convention `AC_Class_Name` → `includes/class-ac-class-name.php`
(`ac_autoload()` in the main plugin file). Each class is a narrow-purpose
singleton or static utility:

| Class            | Responsibility                                                        |
|------------------|-------------------------------------------------------------------------|
| `AC_DB`          | Table names, schema install/upgrade, all submission CRUD + queries.    |
| `AC_Fields`      | Field-builder data layer: default fields, ordering, add/delete/restore.|
| `AC_Helpers`     | Stateless helpers: WhatsApp/mailto URL builders, sanitizers, badges.   |
| `AC_Page`        | Auto-creates/heals the Contact Us page, syncs title/slug/content.      |
| `AC_Frontend`    | The `[advisers_contact_form]` shortcode + guest submission handler.    |
| `AC_Admin`       | wp-admin menus, screens, admin-post.php handlers, AJAX.                |
| `AC_List_Table`  | `WP_List_Table` subclass powering the submissions dashboard.           |

Views live in `includes/views/` and are plain PHP templates `require`d by
`AC_Admin`'s screen-render methods — no templating engine, matching core
WordPress admin conventions.

## Database schema

Two custom tables, both prefixed with the current site's `$wpdb->prefix`
(so on multisite each site gets its own pair — see "Multisite" below).

### `{prefix}ac_submissions`

| Column           | Type              | Notes                                             |
|------------------|-------------------|----------------------------------------------------|
| id               | BIGINT UNSIGNED   | Primary key.                                        |
| full_name        | VARCHAR(191)      | Indexed implicitly via search; core column.         |
| mobile_number    | VARCHAR(32)       | Raw as submitted; WhatsApp link built at render time.|
| email            | VARCHAR(191)      |                                                      |
| subject          | VARCHAR(191)      |                                                      |
| referred_by      | VARCHAR(191)      | Indexed (`KEY referred_by`). Drives the Referrers screen.|
| status           | VARCHAR(20)       | `pending` \| `approved` \| `rejected`. Indexed.     |
| is_important     | TINYINT(1)        | Indexed.                                            |
| field_data       | LONGTEXT          | JSON blob of every non-core field's value.          |
| attachment_ids   | VARCHAR(255)      | Comma-separated Media Library attachment IDs.       |
| ip_address       | VARCHAR(100)      |                                                      |
| user_agent       | VARCHAR(255)      |                                                      |
| created_at       | DATETIME          | Indexed.                                            |
| updated_at       | DATETIME          |                                                      |

Only five fields (`full_name`, `mobile_number`, `email`, `subject`,
`referred_by`) get real, indexed columns — chosen because they're the ones
searched/filtered/sorted on in the dashboard. Every other field (including
any custom field an admin adds) lives in the `field_data` JSON blob, so
the Field Builder can add/remove/reorder fields freely without ever
requiring an `ALTER TABLE`.

### `{prefix}ac_fields`

| Column        | Type            | Notes                                                   |
|---------------|-----------------|-----------------------------------------------------------|
| id            | BIGINT UNSIGNED | Primary key.                                                |
| field_key     | VARCHAR(64)     | Unique. `full_name`, `mobile_number`, etc. for defaults; `custom_*` for admin-added fields.|
| label         | VARCHAR(191)    | Editable by the admin.                                      |
| type          | VARCHAR(20)     | text, textarea, email, tel, url, date, select, file, submit. |
| options       | LONGTEXT        | JSON array; only used by `select` fields.                   |
| placeholder   | VARCHAR(191)    |                                                              |
| is_required   | TINYINT(1)      |                                                              |
| is_enabled    | TINYINT(1)      | Disabled fields are skipped on the front-end form.           |
| is_locked     | TINYINT(1)      | Unused since 1.1.0 (all fields are fully manageable); column kept for backward compatibility with any 1.0.0 data. |
| sort_order    | INT             | Drives both form render order and Field Builder drag order.  |
| created_at    | DATETIME        |                                                              |
| updated_at    | DATETIME        |                                                              |

## Hooks

### Actions

**`ac_after_submission( int $id, array $data )`**
Fires immediately after a contact form submission is stored (guest or
logged-in). `$data` is the array that was written to `ac_submissions`.
Use this to add email notifications, third-party CRM sync, Slack pings,
etc.

```php
add_action( 'ac_after_submission', function ( $id, $data ) {
    wp_mail( get_option( 'admin_email' ), 'New contact form submission', 'Submission #' . $id );
}, 10, 2 );
```

### Filters

**`ac_capability( string $capability )`** — *since 1.1.0*
Filters the capability required to view/manage every Advisers Contacts
admin screen. Default `manage_options`.

```php
add_filter( 'ac_capability', function () {
    return 'manage_advisers_contacts'; // a custom capability
} );
```

**`ac_max_upload_bytes( int $bytes )`**
Filters the maximum size (in bytes) accepted per uploaded file on the
front-end form. Default `5 * MB_IN_BYTES`.

```php
add_filter( 'ac_max_upload_bytes', function () {
    return 10 * MB_IN_BYTES;
} );
```

## Multisite

Advisers Contacts can be activated per-site **or** Network Activated; both
are fully supported.

- **Data model:** submissions, field definitions, and the Contact Us page
  are all **per-site** — each site on the network gets its own tables
  (`{site_prefix}ac_submissions`, `{site_prefix}ac_fields`) and its own
  Contact Us page. There is no shared, network-wide submissions table,
  because a site's contact form leads belong to that site.
- **Network Activation:** provisions every existing site in the network
  (tables, default fields, Contact Us page) by looping `get_sites()` and
  using `switch_to_blog()`/`restore_current_blog()` per site.
- **New sites:** if the plugin is network-active, any site created
  afterward is auto-provisioned via the `wp_initialize_site` hook — no
  manual re-activation needed.
- **Site deletion:** the plugin's two tables are registered with core's
  `wpmu_drop_tables` filter, so when a super admin deletes a site from
  Network Admin → Sites, WordPress's own site-deletion routine drops
  `ac_submissions`/`ac_fields` for that site along with its other tables.
  This is the documented, official mechanism for this — no custom
  `DROP TABLE` hook is needed.
- **Uninstall:** `uninstall.php` detects `is_multisite()` and loops every
  site (`switch_to_blog()`) to drop tables and delete options site by
  site, since `uninstall.php` itself only runs once for the whole network
  delete action, not once per site.
- **Capability:** `ac_get_capability()` (default `manage_options`) is
  evaluated per-site, so each site's own Administrators can manage their
  site's contact form without needing Super Admin privileges — the same
  behavior as any other per-site WordPress setting.

At very large network scale (many thousands of sites), the activation and
uninstall loops run synchronously and could be slow; for that scale,
batch `get_sites()` with `number`/`offset` and consider running
provisioning via a background/cron job instead. For typical networks
(tens to low hundreds of sites) the current implementation is
production-ready as-is.

## Coding standards

The codebase follows WordPress core coding conventions: tabs for
indentation, Yoda conditions, `snake_case` functions, PHPDoc on every
class/method with `@since` tags, and full escaping (`esc_html`,
`esc_attr`, `esc_url`, `wp_kses_post`) on every piece of output plus
`sanitize_*`/`absint`/`wp_verify_nonce` on every piece of input. Every
state-changing request (admin-post.php handlers, AJAX) is nonce-protected
and capability-checked.

Before submitting changes, run the official
[Plugin Check](https://wordpress.org/plugins/plugin-check/) tool against
the plugin — it catches i18n/security/performance issues this document
can't substitute for.
