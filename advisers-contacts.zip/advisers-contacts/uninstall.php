<?php
/**
 * Uninstall handler for Advisers Contacts.
 *
 * Fires only when the plugin is deleted (not on simple deactivation) via
 * wp-admin's Plugins screen — or the Network Admin Plugins screen on a
 * multisite install. Removes the plugin's custom tables and options.
 *
 * On multisite, this file runs ONCE for the whole network, not once per
 * site, so it must loop every site itself and switch into each one to
 * clean up that site's tables/options — the standard pattern documented
 * in the WordPress Plugin Handbook for multisite-aware uninstall.php.
 *
 * The auto-created Contact Us page is deliberately left in place on every
 * site, since it may contain content the site owner still wants, and
 * WordPress.org guidelines discourage deleting content on uninstall
 * unless the site owner explicitly opted in.
 *
 *
 * @package Advisers_Contacts
 * @since 1.0.0
 * @since 1.1.0 Made multisite-aware (loops every site on the network).
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Drop this plugin's tables and delete its options for whichever site is
 * currently in context (the main site on single-site installs, or the
 * site most recently switched into via switch_to_blog() on multisite).
 *
 * @since 1.1.0
 */
function ac_uninstall_current_site() {
	global $wpdb;

	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}ac_submissions" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}ac_fields" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

	$options = array(
		'ac_db_version',
		'ac_page_id',
		'ac_page_title',
		'ac_page_slug',
		'ac_page_content',
		'ac_default_country_code',
		'ac_per_page',
		'ac_notify_email',
	);

	foreach ( $options as $option ) {
		delete_option( $option );
	}
}

if ( is_multisite() ) {
	$ac_site_ids = get_sites( array( 'fields' => 'ids' ) );

	foreach ( $ac_site_ids as $ac_site_id ) {
		switch_to_blog( (int) $ac_site_id );
		ac_uninstall_current_site();
		restore_current_blog();
	}
} else {
	ac_uninstall_current_site();
}
