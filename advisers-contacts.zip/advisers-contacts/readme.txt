=== Advisers Contacts ===
Contributors: myadvisers
Tags: contact form, drag and drop, leads, referral tracking, whatsapp
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A fully manageable, drag-and-drop contact form with a submissions dashboard, referrer tracking and one-click WhatsApp/email links. Multisite compatible.

== Description ==

Advisers Contacts adds a customizable contact form to your WordPress site along with a full submissions dashboard in wp-admin.

**Features**

* Drag-and-drop field builder — reorder, relabel, enable/disable and permanently delete or restore any field, including the default ones.
* 14 ready-to-use fields out of the box: Full Name, Date of Birth, Parent Name, Gender, Religion, Nationality, Mobile Number, Email ID, Residential Address, Website URL, Subject, Requirements, Upload Files, Referred By — plus the Submit button.
* Add unlimited custom fields (text, textarea, email, phone, URL, date, dropdown, file upload).
* Guest submissions — no login required to submit the form.
* Submissions dashboard with search, status/referrer/date filters, sortable columns and pagination.
* Detailed submission view with inline editing.
* Approve, Reject, Delete and Mark Important actions, individually or in bulk.
* Referrer tracking: see how many referrals each referrer has sent and the approved/rejected/pending history of each one.
* Mobile numbers render as one-click WhatsApp (`wa.me`) links; email addresses render as `mailto:` links, both directly inside the admin dashboard.
* Auto-creates a "Contact Us" page carrying the `[advisers_contact_form]` shortcode; editable title, slug and content from Settings, and automatically re-created if the page is ever deleted.
* File uploads are stored in the standard WordPress Media Library.
* Built with dedicated database tables (not post meta), with full CRUD support.
* Full WordPress Multisite support — safe to activate per-site or Network Activate.

= Shortcode =

`[advisers_contact_form]`

== Installation ==

1. Upload the `advisers-contacts` folder to `/wp-content/plugins/`, or install the zip via **Plugins → Add New → Upload Plugin**.
2. Activate the plugin through the **Plugins** screen (or, on a multisite network, **Network Activate** it from Network Admin → Plugins).
3. A "Contact Us" page is created automatically on every activated site. Visit **Advisers Contacts → Contact Page** to customize its title, slug and content.
4. Visit **Advisers Contacts → Field Builder** to customize the form fields.
5. Submissions appear under **Advisers Contacts → Submissions**.

== Frequently Asked Questions ==

= Do visitors need an account to submit the form? =

No. The form accepts submissions from logged-out (guest) visitors as well as logged-in users.

= Can I remove the default fields? =

Yes — every field, including Full Name, Mobile Number, Email ID and Submit, can be disabled, reordered, relabeled or permanently deleted from the Field Builder. Any deleted default field can be added back with one click from the "Restore a Default Field" section.

= Where do uploaded files go? =

Into the standard WordPress Media Library, the same as any other upload.

= What happens to my data if I deactivate the plugin? =

Nothing — deactivating keeps all tables and settings intact. Data is only removed if you explicitly delete the plugin from the Plugins screen.

= Does this work on WordPress Multisite? =

Yes. You can activate it per-site or Network Activate it. Network Activation provisions every existing site, and any site created afterward is provisioned automatically. Submissions, fields and the Contact Us page are kept separately per site — see DEVELOPER.md in the plugin's folder for full technical detail.

== Changelog ==

= 1.1.0 =
* Added full WordPress Multisite support: Network Activation provisions every site, new sites are auto-provisioned, and site deletion cleans up that site's tables via the core `wpmu_drop_tables` filter.
* Every field in the Field Builder (including Full Name, Mobile Number, Email ID and Submit) can now be disabled or permanently deleted, with a one-click "Restore a Default Field" option to add any of them back.
* Added the `ac_capability` filter so the admin capability required to manage the plugin can be customized.
* Updated "Tested up to" to WordPress 7.1.
* Added full developer documentation (DEVELOPER.md) covering the database schema and every hook.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.1.0 =
Adds Multisite support and makes every form field fully removable/restorable. Safe to update in place; no manual steps required.
