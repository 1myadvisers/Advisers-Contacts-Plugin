/* global jQuery, acAdmin */
( function ( $ ) {
	'use strict';

	$( function () {

		/* ---------------------------------------------------------
		 * Field builder: drag-drop reordering
		 * ------------------------------------------------------- */
		var $fieldList = $( '#ac-field-list' );

		if ( $fieldList.length ) {
			$fieldList.sortable( {
				handle: '.ac-drag-handle',
				axis: 'y',
				items: '> li',
				update: function () {
					// no-op; order is read from the DOM on submit.
				}
			} );

			$( '#ac-field-order-form' ).on( 'submit', function () {
				var rows = [];
				var step = 10;

				$fieldList.find( '.ac-field-row' ).each( function ( index ) {
					var $row = $( this );
					rows.push( {
						id: $row.data( 'id' ),
						sort_order: ( index + 1 ) * step,
						label: $row.find( '.ac-field-label' ).val(),
						is_enabled: $row.find( '.ac-field-enabled' ).is( ':checked' ) ? 1 : 0,
						is_required: $row.find( '.ac-field-required' ).is( ':checked' ) ? 1 : 0
					} );
				} );

				$( '#ac-fields-json' ).val( JSON.stringify( rows ) );
			} );
		}

		/* ---------------------------------------------------------
		 * Submissions list: quick "star" toggle (AJAX, no reload)
		 * ------------------------------------------------------- */
		$( document ).on( 'click', '.ac-star-toggle', function () {
			var $btn = $( this );
			var id   = $btn.data( 'id' );
			var $icon = $btn.find( '.dashicons' );

			$btn.prop( 'disabled', true );

			$.post( acAdmin.ajaxUrl, {
				action: 'ac_quick_toggle_important',
				nonce: acAdmin.nonce,
				id: id
			} ).done( function ( response ) {
				if ( response && response.success ) {
					if ( response.data.important ) {
						$icon.removeClass( 'dashicons-star-empty' ).addClass( 'dashicons-star-filled' );
					} else {
						$icon.removeClass( 'dashicons-star-filled' ).addClass( 'dashicons-star-empty' );
					}
				}
			} ).always( function () {
				$btn.prop( 'disabled', false );
			} );
		} );

		/* ---------------------------------------------------------
		 * Submissions list: row "Delete" action via hidden form
		 * ------------------------------------------------------- */
		$( document ).on( 'click', '.ac-delete-link', function ( e ) {
			e.preventDefault();

			if ( ! window.confirm( acAdmin.i18n.confirmDelete ) ) {
				return;
			}

			var id = $( this ).data( 'id' );

			$( '#ac-row-action-name' ).val( 'ac_delete_submission' );
			$( '#ac-row-action-id' ).val( id );
			$( '#ac-row-action-form' ).trigger( 'submit' );
		} );

		/* ---------------------------------------------------------
		 * Submissions list: bulk action dropdown → admin-post routing
		 * WP_List_Table renders native <select name="action"> /
		 * "action2" dropdowns; disable them on submit so only our
		 * hidden "action=ac_bulk_action" field reaches admin-post.php.
		 * ------------------------------------------------------- */
		var $bulkForm = $( '#ac-submissions-form' );

		if ( $bulkForm.length ) {
			$bulkForm.on( 'submit', function ( e ) {
				var $top    = $bulkForm.find( 'select[name="action"]' );
				var $bottom = $bulkForm.find( 'select[name="action2"]' );
				var chosen  = $top.val();

				if ( ! chosen || '-1' === chosen ) {
					chosen = $bottom.val();
				}

				if ( ! chosen || '-1' === chosen ) {
					return; // let native validation / no-op happen
				}

				if ( ! $bulkForm.find( 'input[name="ids[]"]:checked' ).length ) {
					e.preventDefault();
					window.alert( 'Please select at least one submission.' );
					return;
				}

				$( '#ac-bulk-action-field' ).val( chosen );
				$top.add( $bottom ).prop( 'disabled', true );
			} );
		}

	} );
} )( jQuery );
