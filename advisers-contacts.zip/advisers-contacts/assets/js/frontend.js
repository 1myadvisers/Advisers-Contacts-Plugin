/* global jQuery */
( function ( $ ) {
	'use strict';

	$( function () {
		$( '.ac-form' ).on( 'submit', function () {
			$( this ).find( '.ac-submit-btn' ).prop( 'disabled', true ).text( 'Sending…' );
		} );
	} );
} )( jQuery );
