<?php
/**
 * Static helper utilities for Advisers Contacts.
 *
 * @package Advisers_Contacts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AC_Helpers
 * @since 1.0.0
 */
class AC_Helpers {

	/**
	 * Build a click-to-chat WhatsApp URL from a raw mobile number.
	 *
	 * Strips everything but digits, then prepends the configured default
	 * country code only if the number looks too short to already contain
	 * one (fewer digits than the country code + a typical local number).
	 *
	 * @since 1.0.0
	 * @param string $mobile_number Raw mobile number as submitted.
	 * @return string Empty string if no usable digits are found.
	 */
	public static function whatsapp_url( $mobile_number ) {
		$digits = preg_replace( '/\D+/', '', (string) $mobile_number );
		if ( '' === $digits ) {
			return '';
		}

		$default_cc = preg_replace( '/\D+/', '', (string) get_option( 'ac_default_country_code', '91' ) );

		if ( $default_cc && strlen( $digits ) <= 10 ) {
			$digits = $default_cc . $digits;
		}

		return 'https://wa.me/' . $digits;
	}

	/**
	 * Build a mailto: URL from a raw email address.
	 *
	 * @since 1.0.0
	 * @param string $email Email address.
	 * @return string Empty string if not a valid email.
	 */
	public static function mailto_url( $email ) {
		$email = sanitize_email( $email );
		if ( ! is_email( $email ) ) {
			return '';
		}
		return 'mailto:' . antispambot( $email );
	}

	/**
	 * Human-readable, translated status labels.
	 *
	 * @since 1.0.0
	 * @return array status_key => label
	 */
	public static function statuses() {
		return array(
			'pending'  => __( 'Pending', 'advisers-contacts' ),
			'approved' => __( 'Approved', 'advisers-contacts' ),
			'rejected' => __( 'Rejected', 'advisers-contacts' ),
		);
	}

	/**
	 * CSS class used for the colored status badge in wp-admin.
	 *
	 * @since 1.0.0
	 * @param string $status Status key.
	 * @return string
	 */
	public static function status_badge_class( $status ) {
		$map = array(
			'pending'  => 'ac-badge-pending',
			'approved' => 'ac-badge-approved',
			'rejected' => 'ac-badge-rejected',
		);
		return isset( $map[ $status ] ) ? $map[ $status ] : 'ac-badge-pending';
	}

	/**
	 * Sanitize a submitted value according to a field's declared type.
	 *
	 * @since 1.0.0
	 * @param string $type  Field type (text, email, tel, url, date, textarea, select).
	 * @param mixed  $value Raw value.
	 * @return string
	 */
	public static function sanitize_field_value( $type, $value ) {
		switch ( $type ) {
			case 'email':
				return sanitize_email( wp_unslash( $value ) );
			case 'url':
				return esc_url_raw( wp_unslash( $value ) );
			case 'textarea':
				return sanitize_textarea_field( wp_unslash( $value ) );
			case 'tel':
				return preg_replace( '/[^0-9+\-\s()]/', '', wp_unslash( $value ) );
			case 'date':
				$value = sanitize_text_field( wp_unslash( $value ) );
				return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ? $value : '';
			default:
				return sanitize_text_field( wp_unslash( $value ) );
		}
	}

	/**
	 * Get the display value + a viewable URL for each attachment ID stored
	 * against a submission.
	 *
	 * @since 1.0.0
	 * @param string $attachment_ids Comma-separated attachment IDs.
	 * @return array[] { id, title, url }
	 */
	public static function get_attachments( $attachment_ids ) {
		$out = array();
		if ( empty( $attachment_ids ) ) {
			return $out;
		}

		foreach ( array_filter( explode( ',', $attachment_ids ) ) as $id ) {
			$id  = (int) $id;
			$url = wp_get_attachment_url( $id );
			if ( ! $url ) {
				continue;
			}
			$out[] = array(
				'id'    => $id,
				'title' => get_the_title( $id ),
				'url'   => $url,
			);
		}

		return $out;
	}
}
