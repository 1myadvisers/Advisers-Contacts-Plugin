<?php
/**
 * Field-builder data layer for Advisers Contacts.
 *
 * @package Advisers_Contacts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AC_Fields
 *
 * Manages the row set in wp_ac_fields that drives both the front-end
 * form render order and the admin field-builder screen.
 * @since 1.0.0
 */
class AC_Fields {

	/** @var AC_Fields|null */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @since 1.0.0
	 * @return AC_Fields
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * The 15 fields requested for the plugin. Every field — including
	 * Full Name, Mobile Number, Email ID and the Submit button — is fully
	 * manageable: the admin can disable, reorder, relabel or permanently
	 * delete any of them from the Field Builder, and re-add any deleted
	 * default later via "Restore a Default Field". None are hard-locked.
	 *
	 * Note: even if the Submit field row is deleted, AC_Frontend always
	 * renders a working submit control so the form itself never breaks.
	 *
	 * @since 1.0.0
	 * @return array[]
	 */
	private static function default_definitions() {
		return array(
			array( 'key' => 'full_name', 'label' => __( 'Full Name', 'advisers-contacts' ), 'type' => 'text', 'required' => 1 ),
			array( 'key' => 'date_of_birth', 'label' => __( 'Date of Birth', 'advisers-contacts' ), 'type' => 'date', 'required' => 0 ),
			array( 'key' => 'parent_name', 'label' => __( 'Parent Name', 'advisers-contacts' ), 'type' => 'text', 'required' => 0 ),
			array(
				'key'      => 'gender',
				'label'    => __( 'Gender', 'advisers-contacts' ),
				'type'     => 'select',
				'required' => 0,
				'options'  => array( 'Male', 'Female', 'Other', 'Prefer not to say' ),
			),
			array( 'key' => 'religion', 'label' => __( 'Religion', 'advisers-contacts' ), 'type' => 'text', 'required' => 0 ),
			array( 'key' => 'nationality', 'label' => __( 'Nationality', 'advisers-contacts' ), 'type' => 'text', 'required' => 0 ),
			array( 'key' => 'mobile_number', 'label' => __( 'Mobile Number', 'advisers-contacts' ), 'type' => 'tel', 'required' => 1 ),
			array( 'key' => 'email', 'label' => __( 'Email ID', 'advisers-contacts' ), 'type' => 'email', 'required' => 1 ),
			array( 'key' => 'residential_address', 'label' => __( 'Residential Address', 'advisers-contacts' ), 'type' => 'textarea', 'required' => 0 ),
			array( 'key' => 'website_url', 'label' => __( 'Website URL', 'advisers-contacts' ), 'type' => 'url', 'required' => 0 ),
			array( 'key' => 'subject', 'label' => __( 'Subject', 'advisers-contacts' ), 'type' => 'text', 'required' => 0 ),
			array( 'key' => 'requirements', 'label' => __( 'Requirements', 'advisers-contacts' ), 'type' => 'textarea', 'required' => 0 ),
			array( 'key' => 'upload_files', 'label' => __( 'Upload Files', 'advisers-contacts' ), 'type' => 'file', 'required' => 0 ),
			array( 'key' => 'referred_by', 'label' => __( 'Referred By', 'advisers-contacts' ), 'type' => 'text', 'required' => 0 ),
			array( 'key' => 'submit_button', 'label' => __( 'Submit', 'advisers-contacts' ), 'type' => 'submit', 'required' => 0 ),
		);
	}

	/**
	 * Default field definitions that are NOT currently present in the
	 * fields table (i.e. were deleted by the admin and can be restored).
	 *
	 *
	 * @since 1.1.0
	 * @return array[]
	 */
	public static function get_restorable_defaults() {
		global $wpdb;
		$table = AC_DB::fields_table();

		$existing = $wpdb->get_col( "SELECT field_key FROM {$table}" );

		return array_values(
			array_filter(
				self::default_definitions(),
				function ( $def ) use ( $existing ) {
					return ! in_array( $def['key'], $existing, true );
				}
			)
		);
	}

	/**
	 * Re-add a previously deleted default field, preserving its original
	 * key/type/required mapping. Appended to the end of the field order;
	 * the admin can drag it wherever they like afterward.
	 *
	 *
	 * @since 1.1.0
	 * @param string $key One of the default field keys.
	 * @return int|WP_Error New field ID, or WP_Error on failure.
	 */
	public static function restore_field( $key ) {
		global $wpdb;
		$table = AC_DB::fields_table();

		$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE field_key = %s", $key ) );
		if ( $existing ) {
			return new WP_Error( 'ac_exists', __( 'That field already exists in your form.', 'advisers-contacts' ) );
		}

		$def = null;
		foreach ( self::default_definitions() as $candidate ) {
			if ( $candidate['key'] === $key ) {
				$def = $candidate;
				break;
			}
		}
		if ( ! $def ) {
			return new WP_Error( 'ac_unknown_field', __( 'Unknown default field.', 'advisers-contacts' ) );
		}

		$max_order = (int) $wpdb->get_var( "SELECT MAX(sort_order) FROM {$table}" );

		$inserted = $wpdb->insert(
			$table,
			array(
				'field_key'   => $def['key'],
				'label'       => $def['label'],
				'type'        => $def['type'],
				'options'     => ! empty( $def['options'] ) ? wp_json_encode( $def['options'] ) : '',
				'placeholder' => '',
				'is_required' => (int) $def['required'],
				'is_enabled'  => 1,
				'is_locked'   => 0,
				'sort_order'  => $max_order + 10,
				'created_at'  => current_time( 'mysql' ),
				'updated_at'  => current_time( 'mysql' ),
			)
		);

		return $inserted ? (int) $wpdb->insert_id : new WP_Error( 'ac_insert_failed', __( 'Could not restore the field.', 'advisers-contacts' ) );
	}

	/**
	 * Seed the default field set the first time the plugin runs. Safe to
	 * call repeatedly — existing rows (matched by field_key) are left
	 * untouched so admin customizations are never overwritten.
	 * @since 1.0.0
	 */
	public static function maybe_seed_defaults() {
		global $wpdb;
		$table = AC_DB::fields_table();

		$existing = $wpdb->get_col( "SELECT field_key FROM {$table}" );

		$order = 10;
		foreach ( self::default_definitions() as $def ) {
			if ( in_array( $def['key'], $existing, true ) ) {
				$order += 10;
				continue;
			}

			$wpdb->insert(
				$table,
				array(
					'field_key'   => $def['key'],
					'label'       => $def['label'],
					'type'        => $def['type'],
					'options'     => ! empty( $def['options'] ) ? wp_json_encode( $def['options'] ) : '',
					'placeholder' => '',
					'is_required' => (int) $def['required'],
					'is_enabled'  => 1,
					'is_locked'   => 0,
					'sort_order'  => $order,
					'created_at'  => current_time( 'mysql' ),
					'updated_at'  => current_time( 'mysql' ),
				)
			);
			$order += 10;
		}
	}

	/**
	 * Get all fields ordered for display.
	 *
	 * @since 1.0.0
	 * @param bool $enabled_only Whether to only return enabled fields.
	 * @return object[]
	 */
	public static function get_fields( $enabled_only = false ) {
		global $wpdb;
		$table = AC_DB::fields_table();

		$sql = "SELECT * FROM {$table}";
		if ( $enabled_only ) {
			$sql .= ' WHERE is_enabled = 1';
		}
		$sql .= ' ORDER BY sort_order ASC, id ASC';

		return $wpdb->get_results( $sql );
	}

	/**
	 * Get a single field definition by key.
	 *
	 * @since 1.0.0
	 * @param string $key Field key.
	 * @return object|null
	 */
	public static function get_field( $key ) {
		global $wpdb;
		$table = AC_DB::fields_table();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE field_key = %s", $key ) );
	}

	/**
	 * Save the drag-drop order + enabled/required toggles from the field
	 * builder screen in one pass.
	 *
	 * @since 1.0.0
	 * @param array $rows Array of assoc arrays: id, sort_order, is_enabled, is_required, label.
	 */
	public static function save_order( $rows ) {
		global $wpdb;
		$table = AC_DB::fields_table();

		foreach ( $rows as $row ) {
			$id = isset( $row['id'] ) ? (int) $row['id'] : 0;
			if ( ! $id ) {
				continue;
			}

			$field = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );
			if ( ! $field ) {
				continue;
			}

			$update = array(
				'sort_order'  => isset( $row['sort_order'] ) ? (int) $row['sort_order'] : $field->sort_order,
				'label'       => isset( $row['label'] ) ? sanitize_text_field( $row['label'] ) : $field->label,
				'is_enabled'  => isset( $row['is_enabled'] ) ? (int) (bool) $row['is_enabled'] : $field->is_enabled,
				'is_required' => isset( $row['is_required'] ) ? (int) (bool) $row['is_required'] : $field->is_required,
				'updated_at'  => current_time( 'mysql' ),
			);

			$wpdb->update( $table, $update, array( 'id' => $id ) );
		}
	}

	/**
	 * Add a new custom field.
	 *
	 * @since 1.0.0
	 * @param array $data label, type, options (array|string), required, placeholder.
	 * @return int|WP_Error New field ID, or WP_Error on failure.
	 */
	public static function add_field( $data ) {
		global $wpdb;
		$table = AC_DB::fields_table();

		$label = isset( $data['label'] ) ? sanitize_text_field( $data['label'] ) : '';
		if ( '' === $label ) {
			return new WP_Error( 'ac_missing_label', __( 'A field label is required.', 'advisers-contacts' ) );
		}

		$allowed_types = array( 'text', 'textarea', 'email', 'tel', 'url', 'date', 'select', 'file' );
		$type          = isset( $data['type'] ) && in_array( $data['type'], $allowed_types, true ) ? $data['type'] : 'text';

		$key  = sanitize_key( 'custom_' . sanitize_title( $label ) . '_' . wp_generate_password( 4, false, false ) );

		$options = array();
		if ( 'select' === $type && ! empty( $data['options'] ) ) {
			$raw     = is_array( $data['options'] ) ? $data['options'] : explode( "\n", (string) $data['options'] );
			$options = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', $raw ) ) ) );
		}

		$max_order = (int) $wpdb->get_var( "SELECT MAX(sort_order) FROM {$table}" );

		// Keep the Submit button last: insert new fields just before it.
		$submit = self::get_field( 'submit_button' );
		$order  = $submit ? (int) $submit->sort_order : ( $max_order + 10 );
		if ( $submit ) {
			$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET sort_order = sort_order + 10 WHERE sort_order >= %d", $submit->sort_order ) );
		}

		$inserted = $wpdb->insert(
			$table,
			array(
				'field_key'   => $key,
				'label'       => $label,
				'type'        => $type,
				'options'     => $options ? wp_json_encode( $options ) : '',
				'placeholder' => isset( $data['placeholder'] ) ? sanitize_text_field( $data['placeholder'] ) : '',
				'is_required' => ! empty( $data['required'] ) ? 1 : 0,
				'is_enabled'  => 1,
				'is_locked'   => 0,
				'sort_order'  => $order,
				'created_at'  => current_time( 'mysql' ),
				'updated_at'  => current_time( 'mysql' ),
			)
		);

		return $inserted ? (int) $wpdb->insert_id : new WP_Error( 'ac_insert_failed', __( 'Could not save the new field.', 'advisers-contacts' ) );
	}

	/**
	 * Delete any field — default or custom. Deleting a field only removes
	 * it from the form/field-builder; the underlying submissions table
	 * column (for the five core fields) is left untouched, so no data is
	 * lost and the field can be restored later via restore_field().
	 *
	 * @since 1.0.0
	 * @param int $id Field ID.
	 * @return bool|WP_Error
	 */
	public static function delete_field( $id ) {
		global $wpdb;
		$table = AC_DB::fields_table();

		$field = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ) );
		if ( ! $field ) {
			return new WP_Error( 'ac_not_found', __( 'Field not found.', 'advisers-contacts' ) );
		}

		$wpdb->delete( $table, array( 'id' => (int) $id ), array( '%d' ) );
		return true;
	}
}
