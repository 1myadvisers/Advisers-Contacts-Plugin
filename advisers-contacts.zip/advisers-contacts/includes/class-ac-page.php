<?php
/**
 * Auto-managed "Contact Us" page for Advisers Contacts.
 *
 * @package Advisers_Contacts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AC_Page
 *
 * Creates a WordPress page containing the [advisers_contact_form]
 * shortcode on activation, and re-creates it automatically if the page
 * has been trashed/deleted, mirroring the self-healing pattern used by
 * My Advisers' other custom plugins.
 * @since 1.0.0
 */
class AC_Page {

	/** @var AC_Page|null */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @since 1.0.0
	 * @return AC_Page
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->hooks();
		}
		return self::$instance;
	}

	/**
	 * Register hooks.
	 * @since 1.0.0
	 */
	private function hooks() {
		add_action( 'admin_init', array( $this, 'maybe_heal_page' ) );
	}

	/**
	 * Create the default Contact Us page. Safe to call multiple times —
	 * no-ops if a valid page is already tracked.
	 *
	 * @since 1.0.0
	 * @return int Page ID.
	 */
	public static function create_default_page() {
		$page_id = (int) get_option( 'ac_page_id', 0 );

		if ( $page_id && 'trash' !== get_post_status( $page_id ) && get_post( $page_id ) ) {
			return $page_id;
		}

		$title   = get_option( 'ac_page_title', __( 'Contact Us', 'advisers-contacts' ) );
		$slug    = get_option( 'ac_page_slug', 'contact' );
		$content = get_option( 'ac_page_content', '' );

		$page_id = wp_insert_post(
			array(
				'post_title'   => $title,
				'post_name'    => $slug,
				'post_content' => $content . "\n\n[advisers_contact_form]",
				'post_status'  => 'publish',
				'post_type'    => 'page',
			)
		);

		if ( $page_id && ! is_wp_error( $page_id ) ) {
			update_option( 'ac_page_id', $page_id );
			update_option( 'ac_page_title', $title );
			update_option( 'ac_page_slug', $slug );
		}

		return (int) $page_id;
	}

	/**
	 * Re-create the page if it went missing, on every wp-admin load. Cheap
	 * (single get_post_status lookup) so it is safe to run on admin_init.
	 * @since 1.0.0
	 */
	public function maybe_heal_page() {
		$page_id = (int) get_option( 'ac_page_id', 0 );

		if ( ! $page_id || ! get_post( $page_id ) || 'trash' === get_post_status( $page_id ) ) {
			self::create_default_page();
		}
	}

	/**
	 * Update the page's title/slug/content from the admin settings screen
	 * and keep the shortcode appended so the form never disappears.
	 *
	 * @since 1.0.0
	 * @param string $title   New page title.
	 * @param string $slug    New page slug.
	 * @param string $content New page content (shortcode is appended automatically).
	 * @return bool
	 */
	public static function update_page( $title, $slug, $content ) {
		$page_id = self::create_default_page();

		$shortcode = '[advisers_contact_form]';
		if ( false === strpos( $content, $shortcode ) ) {
			$content = rtrim( $content ) . "\n\n" . $shortcode;
		}

		$result = wp_update_post(
			array(
				'ID'           => $page_id,
				'post_title'   => sanitize_text_field( $title ),
				'post_name'    => sanitize_title( $slug ),
				'post_content' => wp_kses_post( $content ),
			),
			true
		);

		if ( is_wp_error( $result ) ) {
			return false;
		}

		update_option( 'ac_page_title', sanitize_text_field( $title ) );
		update_option( 'ac_page_slug', sanitize_title( $slug ) );
		update_option( 'ac_page_content', wp_kses_post( $content ) );

		return true;
	}
}
