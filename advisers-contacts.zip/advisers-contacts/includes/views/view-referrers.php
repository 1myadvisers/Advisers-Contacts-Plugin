<?php
/**
 * View: Referrers overview + per-referrer submission history.
 *
 * @package Advisers_Contacts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$drill_into = isset( $_GET['referrer'] ) ? sanitize_text_field( wp_unslash( $_GET['referrer'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$stats      = AC_DB::get_referrer_stats();
$statuses   = AC_Helpers::statuses();
?>
<div class="wrap ac-wrap">
	<h1><?php esc_html_e( 'Referrers', 'advisers-contacts' ); ?></h1>

	<?php if ( ! $drill_into ) : ?>
		<p>
			<?php
			printf(
				/* translators: %d: number of distinct referrers */
				esc_html__( '%d distinct referrers have sent submissions through the contact form.', 'advisers-contacts' ),
				(int) AC_DB::count_referrers()
			);
			?>
		</p>

		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Referrer', 'advisers-contacts' ); ?></th>
					<th><?php esc_html_e( 'Total Referrals', 'advisers-contacts' ); ?></th>
					<th><?php esc_html_e( 'Approved', 'advisers-contacts' ); ?></th>
					<th><?php esc_html_e( 'Rejected', 'advisers-contacts' ); ?></th>
					<th><?php esc_html_e( 'Pending', 'advisers-contacts' ); ?></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( ! $stats ) : ?>
					<tr><td colspan="6"><?php esc_html_e( 'No referrals recorded yet.', 'advisers-contacts' ); ?></td></tr>
				<?php endif; ?>
				<?php foreach ( $stats as $row ) : ?>
					<tr>
						<td><strong><?php echo esc_html( $row['referrer'] ); ?></strong></td>
						<td><?php echo (int) $row['total']; ?></td>
						<td><span class="ac-badge ac-badge-approved"><?php echo (int) $row['approved']; ?></span></td>
						<td><span class="ac-badge ac-badge-rejected"><?php echo (int) $row['rejected']; ?></span></td>
						<td><span class="ac-badge ac-badge-pending"><?php echo (int) $row['pending']; ?></span></td>
						<td>
							<a href="<?php echo esc_url( add_query_arg( array( 'page' => 'ac-referrers', 'referrer' => rawurlencode( $row['referrer'] ) ), admin_url( 'admin.php' ) ) ); ?>" class="button">
								<?php esc_html_e( 'View History', 'advisers-contacts' ); ?>
							</a>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

	<?php else : ?>

		<a href="<?php echo esc_url( admin_url( 'admin.php?page=ac-referrers' ) ); ?>" class="page-title-action"><?php esc_html_e( '← All Referrers', 'advisers-contacts' ); ?></a>
		<h2><?php echo esc_html( $drill_into ); ?></h2>

		<?php
		$result = AC_DB::query_submissions(
			array(
				'referrer' => $drill_into,
				'orderby'  => 'created_at',
				'order'    => 'DESC',
				'per_page' => 200,
				'paged'    => 1,
			)
		);
		?>

		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Referred Person', 'advisers-contacts' ); ?></th>
					<th><?php esc_html_e( 'Mobile', 'advisers-contacts' ); ?></th>
					<th><?php esc_html_e( 'Email', 'advisers-contacts' ); ?></th>
					<th><?php esc_html_e( 'Status', 'advisers-contacts' ); ?></th>
					<th><?php esc_html_e( 'Date', 'advisers-contacts' ); ?></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $result['items'] as $item ) : ?>
					<tr>
						<td><?php echo esc_html( $item->full_name ); ?></td>
						<td><a href="<?php echo esc_url( AC_Helpers::whatsapp_url( $item->mobile_number ) ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $item->mobile_number ); ?></a></td>
						<td><a href="<?php echo esc_url( AC_Helpers::mailto_url( $item->email ) ); ?>"><?php echo esc_html( $item->email ); ?></a></td>
						<td><span class="ac-badge <?php echo esc_attr( AC_Helpers::status_badge_class( $item->status ) ); ?>"><?php echo esc_html( isset( $statuses[ $item->status ] ) ? $statuses[ $item->status ] : $item->status ); ?></span></td>
						<td><?php echo esc_html( mysql2date( get_option( 'date_format' ), $item->created_at ) ); ?></td>
						<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=ac-view-submission&id=' . $item->id ) ); ?>"><?php esc_html_e( 'View', 'advisers-contacts' ); ?></a></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>
