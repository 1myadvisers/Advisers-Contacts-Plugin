<?php
/**
 * View: Submission detail + edit screen.
 *
 * Expects $submission (object) to be set by the calling controller.
 *
 * @package Advisers_Contacts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$fields       = AC_Fields::get_fields();
$extra_data   = $submission->field_data ? json_decode( $submission->field_data, true ) : array();
$attachments  = AC_Helpers::get_attachments( $submission->attachment_ids );
$statuses     = AC_Helpers::statuses();
$post_url     = admin_url( 'admin-post.php' );

/**
 * Resolve the current value for a field key from the submission row,
 * falling back to the JSON-stored "extra" data.
 *
 * @param string $key Field key.
 * @return string
 */
$get_value = function ( $key ) use ( $submission, $extra_data ) {
	if ( isset( $submission->$key ) ) {
		return $submission->$key;
	}
	return isset( $extra_data[ $key ] ) ? $extra_data[ $key ] : '';
};
?>
<div class="wrap ac-wrap">
	<h1 class="wp-heading-inline">
		<?php echo esc_html( $submission->full_name ? $submission->full_name : __( 'Submission', 'advisers-contacts' ) ); ?>
		#<?php echo (int) $submission->id; ?>
	</h1>
	<a href="<?php echo esc_url( admin_url( 'admin.php?page=advisers-contacts' ) ); ?>" class="page-title-action"><?php esc_html_e( '← Back to Submissions', 'advisers-contacts' ); ?></a>
	<hr class="wp-header-end" />

	<?php if ( isset( $_GET['ac_notice'] ) && 'saved' === $_GET['ac_notice'] ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Submission updated.', 'advisers-contacts' ); ?></p></div>
	<?php endif; ?>

	<div class="ac-detail-toolbar">
		<span class="ac-badge <?php echo esc_attr( AC_Helpers::status_badge_class( $submission->status ) ); ?>">
			<?php echo esc_html( isset( $statuses[ $submission->status ] ) ? $statuses[ $submission->status ] : $submission->status ); ?>
		</span>

		<?php foreach ( array( 'approved' => __( 'Approve', 'advisers-contacts' ), 'rejected' => __( 'Reject', 'advisers-contacts' ), 'pending' => __( 'Mark Pending', 'advisers-contacts' ) ) as $status_key => $label ) : ?>
			<form method="post" action="<?php echo esc_url( $post_url ); ?>" class="ac-inline-form">
				<input type="hidden" name="action" value="ac_change_status" />
				<input type="hidden" name="id" value="<?php echo (int) $submission->id; ?>" />
				<input type="hidden" name="status" value="<?php echo esc_attr( $status_key ); ?>" />
				<?php wp_nonce_field( 'ac_submissions_action', '_ac_nonce' ); ?>
				<button type="submit" class="button<?php echo $submission->status === $status_key ? ' button-primary' : ''; ?>"><?php echo esc_html( $label ); ?></button>
			</form>
		<?php endforeach; ?>

		<form method="post" action="<?php echo esc_url( $post_url ); ?>" class="ac-inline-form">
			<input type="hidden" name="action" value="ac_toggle_important" />
			<input type="hidden" name="id" value="<?php echo (int) $submission->id; ?>" />
			<?php wp_nonce_field( 'ac_submissions_action', '_ac_nonce' ); ?>
			<button type="submit" class="button">
				<span class="dashicons <?php echo $submission->is_important ? 'dashicons-star-filled' : 'dashicons-star-empty'; ?>"></span>
				<?php echo $submission->is_important ? esc_html__( 'Unmark Important', 'advisers-contacts' ) : esc_html__( 'Mark Important', 'advisers-contacts' ); ?>
			</button>
		</form>

		<form method="post" action="<?php echo esc_url( $post_url ); ?>" class="ac-inline-form" onsubmit="return confirm('<?php echo esc_js( __( 'Delete this submission? This cannot be undone.', 'advisers-contacts' ) ); ?>');">
			<input type="hidden" name="action" value="ac_delete_submission" />
			<input type="hidden" name="id" value="<?php echo (int) $submission->id; ?>" />
			<?php wp_nonce_field( 'ac_submissions_action', '_ac_nonce' ); ?>
			<button type="submit" class="button button-link-delete"><?php esc_html_e( 'Delete', 'advisers-contacts' ); ?></button>
		</form>
	</div>

	<div class="ac-detail-grid">
		<div class="ac-detail-main">
			<h2><?php esc_html_e( 'Submitted Information', 'advisers-contacts' ); ?></h2>
			<table class="widefat striped ac-detail-table">
				<tbody>
				<?php foreach ( $fields as $field ) : ?>
					<?php
					if ( in_array( $field->type, array( 'submit', 'file' ), true ) ) {
						continue;
					}
					$value = $get_value( $field->field_key );
					?>
					<tr>
						<th><?php echo esc_html( $field->label ); ?></th>
						<td>
							<?php if ( 'mobile_number' === $field->field_key && $value ) : ?>
								<a href="<?php echo esc_url( AC_Helpers::whatsapp_url( $value ) ); ?>" target="_blank" rel="noopener noreferrer">
									<span class="dashicons dashicons-whatsapp"></span> <?php echo esc_html( $value ); ?>
								</a>
							<?php elseif ( 'email' === $field->field_key && $value ) : ?>
								<a href="<?php echo esc_url( AC_Helpers::mailto_url( $value ) ); ?>"><?php echo esc_html( $value ); ?></a>
							<?php elseif ( 'website_url' === $field->field_key && $value ) : ?>
								<a href="<?php echo esc_url( $value ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $value ); ?></a>
							<?php else : ?>
								<?php echo $value ? nl2br( esc_html( $value ) ) : '&#8212;'; ?>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>

				<?php if ( $attachments ) : ?>
					<tr>
						<th><?php esc_html_e( 'Upload Files', 'advisers-contacts' ); ?></th>
						<td>
							<?php foreach ( $attachments as $file ) : ?>
								<a href="<?php echo esc_url( $file['url'] ); ?>" target="_blank" rel="noopener noreferrer" class="ac-attachment-link"><?php echo esc_html( $file['title'] ); ?></a><br />
							<?php endforeach; ?>
						</td>
					</tr>
				<?php endif; ?>
				</tbody>
			</table>

			<h2 id="ac-edit"><?php esc_html_e( 'Edit Submission', 'advisers-contacts' ); ?></h2>
			<form method="post" action="<?php echo esc_url( $post_url ); ?>">
				<input type="hidden" name="action" value="ac_update_submission" />
				<input type="hidden" name="id" value="<?php echo (int) $submission->id; ?>" />
				<?php wp_nonce_field( 'ac_submissions_action', '_ac_nonce' ); ?>
				<table class="form-table">
					<?php foreach ( $fields as $field ) : ?>
						<?php
						if ( in_array( $field->type, array( 'submit', 'file' ), true ) ) {
							continue;
						}
						$value = $get_value( $field->field_key );
						$name  = 'ac_field_' . $field->field_key;
						?>
						<tr>
							<th><label for="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $field->label ); ?></label></th>
							<td>
								<?php if ( 'textarea' === $field->type ) : ?>
									<textarea class="large-text" rows="3" id="<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>"><?php echo esc_textarea( $value ); ?></textarea>
								<?php elseif ( 'select' === $field->type ) : ?>
									<?php $options = $field->options ? json_decode( $field->options, true ) : array(); ?>
									<select id="<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>">
										<option value=""><?php esc_html_e( '— Select —', 'advisers-contacts' ); ?></option>
										<?php foreach ( (array) $options as $option ) : ?>
											<option value="<?php echo esc_attr( $option ); ?>" <?php selected( $value, $option ); ?>><?php echo esc_html( $option ); ?></option>
										<?php endforeach; ?>
									</select>
								<?php else : ?>
									<input type="<?php echo 'date' === $field->type ? 'date' : 'text'; ?>" class="regular-text" id="<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" />
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
				<?php submit_button( __( 'Save Changes', 'advisers-contacts' ) ); ?>
			</form>
		</div>

		<div class="ac-detail-side">
			<h2><?php esc_html_e( 'Meta', 'advisers-contacts' ); ?></h2>
			<table class="widefat striped">
				<tbody>
					<tr><th><?php esc_html_e( 'Submitted', 'advisers-contacts' ); ?></th><td><?php echo esc_html( mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $submission->created_at ) ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Last Updated', 'advisers-contacts' ); ?></th><td><?php echo esc_html( mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $submission->updated_at ) ); ?></td></tr>
					<tr><th><?php esc_html_e( 'IP Address', 'advisers-contacts' ); ?></th><td><?php echo esc_html( $submission->ip_address ); ?></td></tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
