<?php
/**
 * View: Field builder (drag-drop reorder + add/remove custom fields).
 *
 * @package Advisers_Contacts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$fields     = AC_Fields::get_fields();
$restorable = AC_Fields::get_restorable_defaults();
$notice     = isset( $_GET['ac_notice'] ) ? sanitize_key( $_GET['ac_notice'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

$notices = array(
	'fields_saved'   => __( 'Field order saved.', 'advisers-contacts' ),
	'field_added'    => __( 'Field added.', 'advisers-contacts' ),
	'field_deleted'  => __( 'Field deleted.', 'advisers-contacts' ),
	'field_restored' => __( 'Field restored.', 'advisers-contacts' ),
	'error'          => __( 'Something went wrong. Please check your input and try again.', 'advisers-contacts' ),
);
?>
<div class="wrap ac-wrap">
	<h1><?php esc_html_e( 'Field Builder', 'advisers-contacts' ); ?></h1>
	<p><?php esc_html_e( 'Fully customizable: drag fields to reorder them, toggle Enabled/Required, relabel, or permanently delete any field — including Full Name, Mobile Number, Email ID and Submit. Deleted default fields can be added back anytime from "Restore a Default Field" below.', 'advisers-contacts' ); ?></p>

	<?php if ( $notice && isset( $notices[ $notice ] ) ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $notices[ $notice ] ); ?></p></div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="ac-field-order-form">
		<input type="hidden" name="action" value="ac_save_field_order" />
		<input type="hidden" name="fields" id="ac-fields-json" value="" />
		<?php wp_nonce_field( 'ac_field_builder', '_ac_nonce' ); ?>

		<ul id="ac-field-list" class="ac-field-list">
			<?php foreach ( $fields as $field ) : ?>
				<li class="ac-field-row" data-id="<?php echo (int) $field->id; ?>">
					<span class="dashicons dashicons-menu ac-drag-handle" aria-hidden="true"></span>
					<input type="text" class="ac-field-label regular-text" value="<?php echo esc_attr( $field->label ); ?>" />
					<span class="ac-field-type"><?php echo esc_html( $field->type ); ?></span>

					<label class="ac-field-toggle">
						<input type="checkbox" class="ac-field-enabled" <?php checked( 1, (int) $field->is_enabled ); ?> />
						<?php esc_html_e( 'Enabled', 'advisers-contacts' ); ?>
					</label>

					<label class="ac-field-toggle">
						<input type="checkbox" class="ac-field-required" <?php checked( 1, (int) $field->is_required ); ?> />
						<?php esc_html_e( 'Required', 'advisers-contacts' ); ?>
					</label>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="ac-inline-form" onsubmit="return confirm('<?php echo esc_js( __( 'Delete this field? This cannot be undone (default fields can be restored later).', 'advisers-contacts' ) ); ?>');">
						<input type="hidden" name="action" value="ac_delete_field" />
						<input type="hidden" name="id" value="<?php echo (int) $field->id; ?>" />
						<?php wp_nonce_field( 'ac_field_builder', '_ac_nonce' ); ?>
						<button type="submit" class="button-link ac-delete-field-link"><span class="dashicons dashicons-trash"></span></button>
					</form>
				</li>
			<?php endforeach; ?>
		</ul>

		<?php submit_button( __( 'Save Field Order', 'advisers-contacts' ) ); ?>
	</form>

	<hr />

	<?php if ( $restorable ) : ?>
		<h2><?php esc_html_e( 'Restore a Default Field', 'advisers-contacts' ); ?></h2>
		<p><?php esc_html_e( 'These default fields have been removed from your form. Add any of them back with one click.', 'advisers-contacts' ); ?></p>
		<table class="widefat striped" style="max-width:600px;">
			<tbody>
				<?php foreach ( $restorable as $def ) : ?>
					<tr>
						<td><?php echo esc_html( $def['label'] ); ?></td>
						<td><span class="ac-field-type"><?php echo esc_html( $def['type'] ); ?></span></td>
						<td>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="ac-inline-form">
								<input type="hidden" name="action" value="ac_restore_field" />
								<input type="hidden" name="field_key" value="<?php echo esc_attr( $def['key'] ); ?>" />
								<?php wp_nonce_field( 'ac_field_builder', '_ac_nonce' ); ?>
								<button type="submit" class="button"><?php esc_html_e( 'Add Back', 'advisers-contacts' ); ?></button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<hr />
	<?php endif; ?>

	<h2><?php esc_html_e( 'Add a Custom Field', 'advisers-contacts' ); ?></h2>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="ac_add_field" />
		<?php wp_nonce_field( 'ac_field_builder', '_ac_nonce' ); ?>
		<table class="form-table">
			<tr>
				<th><label for="ac-new-label"><?php esc_html_e( 'Label', 'advisers-contacts' ); ?></label></th>
				<td><input type="text" id="ac-new-label" name="label" class="regular-text" required /></td>
			</tr>
			<tr>
				<th><label for="ac-new-type"><?php esc_html_e( 'Field Type', 'advisers-contacts' ); ?></label></th>
				<td>
					<select id="ac-new-type" name="type">
						<option value="text"><?php esc_html_e( 'Text', 'advisers-contacts' ); ?></option>
						<option value="textarea"><?php esc_html_e( 'Textarea', 'advisers-contacts' ); ?></option>
						<option value="email"><?php esc_html_e( 'Email', 'advisers-contacts' ); ?></option>
						<option value="tel"><?php esc_html_e( 'Phone', 'advisers-contacts' ); ?></option>
						<option value="url"><?php esc_html_e( 'URL', 'advisers-contacts' ); ?></option>
						<option value="date"><?php esc_html_e( 'Date', 'advisers-contacts' ); ?></option>
						<option value="select"><?php esc_html_e( 'Dropdown', 'advisers-contacts' ); ?></option>
						<option value="file"><?php esc_html_e( 'File Upload', 'advisers-contacts' ); ?></option>
					</select>
				</td>
			</tr>
			<tr>
				<th><label for="ac-new-options"><?php esc_html_e( 'Dropdown Options', 'advisers-contacts' ); ?></label></th>
				<td>
					<textarea id="ac-new-options" name="options" class="large-text" rows="3" placeholder="<?php esc_attr_e( 'One option per line (only used for Dropdown fields)', 'advisers-contacts' ); ?>"></textarea>
				</td>
			</tr>
			<tr>
				<th><label for="ac-new-placeholder"><?php esc_html_e( 'Placeholder', 'advisers-contacts' ); ?></label></th>
				<td><input type="text" id="ac-new-placeholder" name="placeholder" class="regular-text" /></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Required', 'advisers-contacts' ); ?></th>
				<td><label><input type="checkbox" name="required" value="1" /> <?php esc_html_e( 'Make this field mandatory', 'advisers-contacts' ); ?></label></td>
			</tr>
		</table>
		<?php submit_button( __( 'Add Field', 'advisers-contacts' ) ); ?>
	</form>
</div>
