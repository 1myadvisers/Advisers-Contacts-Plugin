<?php
/**
 * View: Submissions dashboard.
 *
 * @package Advisers_Contacts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$list_table = new AC_List_Table();
$list_table->prepare_items();

$notice = isset( $_GET['ac_notice'] ) ? sanitize_key( $_GET['ac_notice'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

$notices = array(
	'status_updated'    => __( 'Status updated.', 'advisers-contacts' ),
	'important_updated' => __( 'Updated.', 'advisers-contacts' ),
	'deleted'            => __( 'Submission deleted.', 'advisers-contacts' ),
	'bulk_done'          => __( 'Bulk action completed.', 'advisers-contacts' ),
);
?>
<div class="wrap ac-wrap">
	<h1 class="wp-heading-inline"><?php esc_html_e( 'Contact Form Submissions', 'advisers-contacts' ); ?></h1>
	<hr class="wp-header-end" />

	<?php if ( $notice && isset( $notices[ $notice ] ) ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $notices[ $notice ] ); ?></p></div>
	<?php endif; ?>

	<form method="get" id="ac-submissions-filter-form">
		<input type="hidden" name="page" value="advisers-contacts" />
		<?php
		$list_table->search_box( __( 'Search submissions', 'advisers-contacts' ), 'ac-search' );
		?>
	</form>

	<form method="post" id="ac-submissions-form"
		action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="ac_bulk_action" />
		<input type="hidden" name="bulk_action" id="ac-bulk-action-field" value="" />
		<?php wp_nonce_field( 'ac_submissions_action', '_ac_nonce' ); ?>

		<?php
		// Preserve current filters as hidden fields so pagination/sort links keep them.
		foreach ( array( 'ac_status', 'ac_referrer', 'ac_date_from', 'ac_date_to', 's' ) as $key ) {
			if ( ! empty( $_REQUEST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				printf( '<input type="hidden" name="%s" value="%s" />', esc_attr( $key ), esc_attr( sanitize_text_field( wp_unslash( $_REQUEST[ $key ] ) ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			}
		}
		$list_table->display();
		?>
	</form>
</div>

<form method="post" id="ac-row-action-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:none;">
	<input type="hidden" name="action" id="ac-row-action-name" value="" />
	<input type="hidden" name="id" id="ac-row-action-id" value="" />
	<?php wp_nonce_field( 'ac_submissions_action', '_ac_nonce' ); ?>
</form>
