<?php
/**
 * View: General settings.
 *
 * @package Advisers_Contacts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$country_code = get_option( 'ac_default_country_code', '91' );
$per_page     = get_option( 'ac_per_page', 20 );
$notify_email = get_option( 'ac_notify_email', get_option( 'admin_email' ) );
$notice       = isset( $_GET['ac_notice'] ) ? sanitize_key( $_GET['ac_notice'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
?>
<div class="wrap ac-wrap">
	<h1><?php esc_html_e( 'Advisers Contacts Settings', 'advisers-contacts' ); ?></h1>

	<?php if ( $notice && 'settings_saved' === $notice ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Settings saved.', 'advisers-contacts' ); ?></p></div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="ac_save_general_settings" />
		<?php wp_nonce_field( 'ac_settings', '_ac_nonce' ); ?>
		<table class="form-table">
			<tr>
				<th><label for="default_country_code"><?php esc_html_e( 'Default WhatsApp Country Code', 'advisers-contacts' ); ?></label></th>
				<td>
					<input type="text" id="default_country_code" name="default_country_code" class="small-text" value="<?php echo esc_attr( $country_code ); ?>" maxlength="4" />
					<p class="description"><?php esc_html_e( 'Prepended to mobile numbers that appear to have no country code when generating the WhatsApp link (e.g. 91 for India).', 'advisers-contacts' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><label for="per_page"><?php esc_html_e( 'Submissions Per Page', 'advisers-contacts' ); ?></label></th>
				<td><input type="number" id="per_page" name="per_page" class="small-text" min="5" max="200" value="<?php echo esc_attr( $per_page ); ?>" /></td>
			</tr>
			<tr>
				<th><label for="notify_email"><?php esc_html_e( 'Notification Email', 'advisers-contacts' ); ?></label></th>
				<td>
					<input type="email" id="notify_email" name="notify_email" class="regular-text" value="<?php echo esc_attr( $notify_email ); ?>" />
					<p class="description"><?php esc_html_e( 'Reserved for future email-notification hooks (ac_after_submission).', 'advisers-contacts' ); ?></p>
				</td>
			</tr>
		</table>
		<?php submit_button( __( 'Save Settings', 'advisers-contacts' ) ); ?>
	</form>
</div>
