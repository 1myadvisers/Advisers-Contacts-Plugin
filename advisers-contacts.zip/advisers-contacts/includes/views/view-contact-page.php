<?php
/**
 * View: Contact Us page settings.
 *
 * @package Advisers_Contacts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$page_id = (int) get_option( 'ac_page_id', 0 );
$title   = get_option( 'ac_page_title', __( 'Contact Us', 'advisers-contacts' ) );
$slug    = get_option( 'ac_page_slug', 'contact' );
$content = get_option( 'ac_page_content', '' );
$notice  = isset( $_GET['ac_notice'] ) ? sanitize_key( $_GET['ac_notice'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
?>
<div class="wrap ac-wrap">
	<h1><?php esc_html_e( 'Contact Page', 'advisers-contacts' ); ?></h1>
	<p>
		<?php esc_html_e( 'This plugin keeps a WordPress page carrying the [advisers_contact_form] shortcode. If the page is ever deleted, it will be automatically re-created.', 'advisers-contacts' ); ?>
		<?php if ( $page_id ) : ?>
			<a href="<?php echo esc_url( get_permalink( $page_id ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'View the live page →', 'advisers-contacts' ); ?></a>
		<?php endif; ?>
	</p>

	<?php if ( $notice && 'page_saved' === $notice ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Contact page updated.', 'advisers-contacts' ); ?></p></div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="ac_save_page_settings" />
		<?php wp_nonce_field( 'ac_contact_page', '_ac_nonce' ); ?>
		<table class="form-table">
			<tr>
				<th><label for="page_title"><?php esc_html_e( 'Page Title', 'advisers-contacts' ); ?></label></th>
				<td><input type="text" id="page_title" name="page_title" class="regular-text" value="<?php echo esc_attr( $title ); ?>" required /></td>
			</tr>
			<tr>
				<th><label for="page_slug"><?php esc_html_e( 'Page Slug', 'advisers-contacts' ); ?></label></th>
				<td>
					<code><?php echo esc_html( home_url( '/' ) ); ?></code>
					<input type="text" id="page_slug" name="page_slug" value="<?php echo esc_attr( $slug ); ?>" required />
				</td>
			</tr>
			<tr>
				<th><label for="page_content"><?php esc_html_e( 'Page Content', 'advisers-contacts' ); ?></label></th>
				<td>
					<?php
					wp_editor(
						$content,
						'page_content',
						array(
							'textarea_name' => 'page_content',
							'textarea_rows' => 10,
							'media_buttons' => true,
						)
					);
					?>
					<p class="description"><?php esc_html_e( 'The [advisers_contact_form] shortcode is appended automatically and always kept on the page.', 'advisers-contacts' ); ?></p>
				</td>
			</tr>
		</table>
		<?php submit_button( __( 'Save Contact Page', 'advisers-contacts' ) ); ?>
	</form>
</div>
