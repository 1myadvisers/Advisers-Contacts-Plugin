<?php
/**
 * Submissions list table.
 *
 * @package Advisers_Contacts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Class AC_List_Table
 *
 * Renders the searchable, filterable, paginated submissions dashboard.
 * @since 1.0.0
 */
class AC_List_Table extends WP_List_Table {

	/**
	 * Constructor.
	 * @since 1.0.0
	 */
	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'submission',
				'plural'   => 'submissions',
				'ajax'     => false,
			)
		);
	}

	/**
	 * Table columns.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public function get_columns() {
		return array(
			'cb'          => '<input type="checkbox" />',
			'important'   => '',
			'full_name'   => __( 'Full Name', 'advisers-contacts' ),
			'mobile'      => __( 'Mobile', 'advisers-contacts' ),
			'email'       => __( 'Email', 'advisers-contacts' ),
			'subject'     => __( 'Subject', 'advisers-contacts' ),
			'referred_by' => __( 'Referred By', 'advisers-contacts' ),
			'status'      => __( 'Status', 'advisers-contacts' ),
			'created_at'  => __( 'Date', 'advisers-contacts' ),
		);
	}

	/**
	 * Sortable columns.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	protected function get_sortable_columns() {
		return array(
			'full_name'   => array( 'full_name', false ),
			'referred_by' => array( 'referred_by', false ),
			'status'      => array( 'status', false ),
			'created_at'  => array( 'created_at', true ),
		);
	}

	/**
	 * Bulk actions.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	protected function get_bulk_actions() {
		return array(
			'approve'     => __( 'Mark Approved', 'advisers-contacts' ),
			'reject'      => __( 'Mark Rejected', 'advisers-contacts' ),
			'important'   => __( 'Mark Important', 'advisers-contacts' ),
			'unimportant' => __( 'Unmark Important', 'advisers-contacts' ),
			'delete'      => __( 'Delete', 'advisers-contacts' ),
		);
	}

	/**
	 * Checkbox column.
	 *
	 * @since 1.0.0
	 * @param object $item Row.
	 * @return string
	 */
	public function column_cb( $item ) {
		return sprintf( '<input type="checkbox" name="ids[]" value="%d" />', $item->id );
	}

	/**
	 * Star toggle column.
	 *
	 * @since 1.0.0
	 * @param object $item Row.
	 * @return string
	 */
	public function column_important( $item ) {
		$class = $item->is_important ? 'dashicons-star-filled' : 'dashicons-star-empty';
		return sprintf(
			'<button type="button" class="ac-star-toggle button-link" data-id="%d" aria-label="%s"><span class="dashicons %s"></span></button>',
			(int) $item->id,
			esc_attr__( 'Toggle important', 'advisers-contacts' ),
			esc_attr( $class )
		);
	}

	/**
	 * Full name column with row actions.
	 *
	 * @since 1.0.0
	 * @param object $item Row.
	 * @return string
	 */
	public function column_full_name( $item ) {
		$view_url = admin_url( 'admin.php?page=ac-view-submission&id=' . $item->id );

		$actions = array(
			'view'   => sprintf( '<a href="%s">%s</a>', esc_url( $view_url ), esc_html__( 'View', 'advisers-contacts' ) ),
			'edit'   => sprintf( '<a href="%s">%s</a>', esc_url( $view_url . '#ac-edit' ), esc_html__( 'Edit', 'advisers-contacts' ) ),
			'delete' => sprintf(
				'<a href="#" class="ac-delete-link" data-id="%d">%s</a>',
				(int) $item->id,
				esc_html__( 'Delete', 'advisers-contacts' )
			),
		);

		return sprintf(
			'<strong><a href="%s">%s</a></strong>%s',
			esc_url( $view_url ),
			esc_html( $item->full_name ? $item->full_name : __( '(no name)', 'advisers-contacts' ) ),
			$this->row_actions( $actions )
		);
	}

	/**
	 * Mobile column, rendered as a WhatsApp click-to-chat link.
	 *
	 * @since 1.0.0
	 * @param object $item Row.
	 * @return string
	 */
	public function column_mobile( $item ) {
		if ( empty( $item->mobile_number ) ) {
			return '&#8212;';
		}
		$url = AC_Helpers::whatsapp_url( $item->mobile_number );
		return sprintf(
			'<a href="%s" target="_blank" rel="noopener noreferrer" class="ac-whatsapp-link"><span class="dashicons dashicons-whatsapp"></span> %s</a>',
			esc_url( $url ),
			esc_html( $item->mobile_number )
		);
	}

	/**
	 * Email column, rendered as a mailto: link.
	 *
	 * @since 1.0.0
	 * @param object $item Row.
	 * @return string
	 */
	public function column_email( $item ) {
		if ( empty( $item->email ) ) {
			return '&#8212;';
		}
		$url = AC_Helpers::mailto_url( $item->email );
		return sprintf( '<a href="%s">%s</a>', esc_url( $url ), esc_html( $item->email ) );
	}

	/**
	 * Status column, rendered as a colored badge.
	 *
	 * @since 1.0.0
	 * @param object $item Row.
	 * @return string
	 */
	public function column_status( $item ) {
		$labels = AC_Helpers::statuses();
		$label  = isset( $labels[ $item->status ] ) ? $labels[ $item->status ] : $item->status;
		return sprintf( '<span class="ac-badge %s">%s</span>', esc_attr( AC_Helpers::status_badge_class( $item->status ) ), esc_html( $label ) );
	}

	/**
	 * Default renderer for plain text columns.
	 *
	 * @since 1.0.0
	 * @param object $item        Row.
	 * @param string $column_name Column key.
	 * @return string
	 */
	public function column_default( $item, $column_name ) {
		switch ( $column_name ) {
			case 'subject':
				return esc_html( $item->subject );
			case 'referred_by':
				return $item->referred_by ? esc_html( $item->referred_by ) : '&#8212;';
			case 'created_at':
				return esc_html( mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $item->created_at ) );
			default:
				return '';
		}
	}

	/**
	 * Extra table nav: status/referrer/date filters.
	 *
	 * @since 1.0.0
	 * @param string $which top|bottom.
	 */
	protected function extra_tablenav( $which ) {
		if ( 'top' !== $which ) {
			return;
		}

		$status    = isset( $_REQUEST['ac_status'] ) ? sanitize_key( $_REQUEST['ac_status'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$referrer  = isset( $_REQUEST['ac_referrer'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['ac_referrer'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$date_from = isset( $_REQUEST['ac_date_from'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['ac_date_from'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$date_to   = isset( $_REQUEST['ac_date_to'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['ac_date_to'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$referrers = AC_DB::get_referrer_stats();
		?>
		<div class="alignleft actions ac-filters">
			<select name="ac_status">
				<option value=""><?php esc_html_e( 'All statuses', 'advisers-contacts' ); ?></option>
				<?php foreach ( AC_Helpers::statuses() as $key => $label ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $status, $key ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>

			<select name="ac_referrer">
				<option value=""><?php esc_html_e( 'All referrers', 'advisers-contacts' ); ?></option>
				<?php foreach ( $referrers as $row ) : ?>
					<option value="<?php echo esc_attr( $row['referrer'] ); ?>" <?php selected( $referrer, $row['referrer'] ); ?>>
						<?php echo esc_html( $row['referrer'] ); ?> (<?php echo (int) $row['total']; ?>)
					</option>
				<?php endforeach; ?>
			</select>

			<label class="screen-reader-text" for="ac_date_from"><?php esc_html_e( 'From date', 'advisers-contacts' ); ?></label>
			<input type="date" name="ac_date_from" value="<?php echo esc_attr( $date_from ); ?>" placeholder="<?php esc_attr_e( 'From', 'advisers-contacts' ); ?>" />

			<label class="screen-reader-text" for="ac_date_to"><?php esc_html_e( 'To date', 'advisers-contacts' ); ?></label>
			<input type="date" name="ac_date_to" value="<?php echo esc_attr( $date_to ); ?>" placeholder="<?php esc_attr_e( 'To', 'advisers-contacts' ); ?>" />

			<?php submit_button( __( 'Filter', 'advisers-contacts' ), '', 'filter_action', false ); ?>
		</div>
		<?php
	}

	/**
	 * Fetch, filter, sort and paginate rows.
	 * @since 1.0.0
	 */
	public function prepare_items() {
		$columns  = $this->get_columns();
		$hidden   = array();
		$sortable = $this->get_sortable_columns();
		$this->_column_headers = array( $columns, $hidden, $sortable );

		$per_page = (int) get_option( 'ac_per_page', 20 );

		$args = array(
			'search'    => isset( $_REQUEST['s'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['s'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			'status'    => isset( $_REQUEST['ac_status'] ) ? sanitize_key( $_REQUEST['ac_status'] ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			'referrer'  => isset( $_REQUEST['ac_referrer'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['ac_referrer'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			'date_from' => isset( $_REQUEST['ac_date_from'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['ac_date_from'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			'date_to'   => isset( $_REQUEST['ac_date_to'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['ac_date_to'] ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			'orderby'   => isset( $_REQUEST['orderby'] ) ? sanitize_key( $_REQUEST['orderby'] ) : 'created_at', // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			'order'     => isset( $_REQUEST['order'] ) ? sanitize_key( $_REQUEST['order'] ) : 'DESC', // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			'per_page'  => $per_page,
			'paged'     => $this->get_pagenum(),
		);

		$result = AC_DB::query_submissions( $args );

		$this->items = $result['items'];

		$this->set_pagination_args(
			array(
				'total_items' => $result['total'],
				'per_page'    => $per_page,
				'total_pages' => (int) ceil( $result['total'] / $per_page ),
			)
		);
	}
}
