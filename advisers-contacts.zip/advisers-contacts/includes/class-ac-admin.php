<?php
/**
 * wp-admin controller for Advisers Contacts.
 *
 * @package Advisers_Contacts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AC_Admin
 * @since 1.0.0
 */
class AC_Admin {

	/** @var AC_Admin|null */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @since 1.0.0
	 * @return AC_Admin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->hooks();
		}
		return self::$instance;
	}

	/**
	 * Register hooks.
	 * @since 1.0.0
	 */
	private function hooks() {
		add_action( 'admin_menu', array( $this, 'register_menus' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );

		add_action( 'admin_post_ac_change_status', array( $this, 'handle_change_status' ) );
		add_action( 'admin_post_ac_toggle_important', array( $this, 'handle_toggle_important' ) );
		add_action( 'admin_post_ac_delete_submission', array( $this, 'handle_delete_submission' ) );
		add_action( 'admin_post_ac_update_submission', array( $this, 'handle_update_submission' ) );
		add_action( 'admin_post_ac_bulk_action', array( $this, 'handle_bulk_action' ) );

		add_action( 'admin_post_ac_save_field_order', array( $this, 'handle_save_field_order' ) );
		add_action( 'admin_post_ac_add_field', array( $this, 'handle_add_field' ) );
		add_action( 'admin_post_ac_delete_field', array( $this, 'handle_delete_field' ) );
		add_action( 'admin_post_ac_restore_field', array( $this, 'handle_restore_field' ) );

		add_action( 'admin_post_ac_save_page_settings', array( $this, 'handle_save_page_settings' ) );
		add_action( 'admin_post_ac_save_general_settings', array( $this, 'handle_save_general_settings' ) );

		add_action( 'wp_ajax_ac_quick_toggle_important', array( $this, 'ajax_quick_toggle_important' ) );
	}

	/**
	 * Register the admin menu and submenus.
	 * @since 1.0.0
	 */
	public function register_menus() {
		add_menu_page(
			__( 'Advisers Contacts', 'advisers-contacts' ),
			__( 'Advisers Contacts', 'advisers-contacts' ),
			ac_get_capability(),
			'advisers-contacts',
			array( $this, 'render_submissions_screen' ),
			'dashicons-email-alt',
			27
		);

		add_submenu_page( 'advisers-contacts', __( 'Submissions', 'advisers-contacts' ), __( 'Submissions', 'advisers-contacts' ), ac_get_capability(), 'advisers-contacts', array( $this, 'render_submissions_screen' ) );
		add_submenu_page( 'advisers-contacts', __( 'Referrers', 'advisers-contacts' ), __( 'Referrers', 'advisers-contacts' ), ac_get_capability(), 'ac-referrers', array( $this, 'render_referrers_screen' ) );
		add_submenu_page( 'advisers-contacts', __( 'Field Builder', 'advisers-contacts' ), __( 'Field Builder', 'advisers-contacts' ), ac_get_capability(), 'ac-field-builder', array( $this, 'render_field_builder_screen' ) );
		add_submenu_page( 'advisers-contacts', __( 'Contact Page', 'advisers-contacts' ), __( 'Contact Page', 'advisers-contacts' ), ac_get_capability(), 'ac-contact-page', array( $this, 'render_contact_page_screen' ) );
		add_submenu_page( 'advisers-contacts', __( 'Settings', 'advisers-contacts' ), __( 'Settings', 'advisers-contacts' ), ac_get_capability(), 'ac-settings', array( $this, 'render_settings_screen' ) );

		// Hidden detail screen, reached only via a row link (not shown in the menu).
		add_submenu_page( null, __( 'Submission Details', 'advisers-contacts' ), '', ac_get_capability(), 'ac-view-submission', array( $this, 'render_view_submission_screen' ) );
	}

	/**
	 * Enqueue admin CSS/JS only on the plugin's own screens.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_assets( $hook ) {
		if ( strpos( $hook, 'advisers-contacts' ) === false && strpos( $hook, 'ac-' ) === false ) {
			return;
		}

		wp_enqueue_style( 'ac-admin', AC_URL . 'assets/css/admin.css', array(), AC_VERSION );
		wp_enqueue_script( 'jquery-ui-sortable' );
		wp_enqueue_script( 'ac-admin', AC_URL . 'assets/js/admin.js', array( 'jquery', 'jquery-ui-sortable' ), AC_VERSION, true );
		wp_localize_script(
			'ac-admin',
			'acAdmin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'ac_admin_ajax' ),
				'i18n'    => array(
					'confirmDelete' => __( 'Delete this submission? This cannot be undone.', 'advisers-contacts' ),
					'confirmField'  => __( 'Delete this field? This cannot be undone.', 'advisers-contacts' ),
				),
			)
		);
	}

	/* -----------------------------------------------------------------
	 * Screens
	 * -------------------------------------------------------------- */

	/**
	 * Submissions dashboard (WP_List_Table).
	 * @since 1.0.0
	 */
	public function render_submissions_screen() {
		if ( ! current_user_can( ac_get_capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'advisers-contacts' ) );
		}
		require AC_DIR . 'includes/views/view-submissions.php';
	}

	/**
	 * Single submission detail/edit screen.
	 * @since 1.0.0
	 */
	public function render_view_submission_screen() {
		if ( ! current_user_can( ac_get_capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'advisers-contacts' ) );
		}
		$id         = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$submission = $id ? AC_DB::get_submission( $id ) : null;

		if ( ! $submission ) {
			echo '<div class="wrap"><h1>' . esc_html__( 'Submission not found', 'advisers-contacts' ) . '</h1></div>';
			return;
		}

		require AC_DIR . 'includes/views/view-submission-detail.php';
	}

	/**
	 * Referrers overview + drill-down.
	 * @since 1.0.0
	 */
	public function render_referrers_screen() {
		if ( ! current_user_can( ac_get_capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'advisers-contacts' ) );
		}
		require AC_DIR . 'includes/views/view-referrers.php';
	}

	/**
	 * Drag-drop field builder.
	 * @since 1.0.0
	 */
	public function render_field_builder_screen() {
		if ( ! current_user_can( ac_get_capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'advisers-contacts' ) );
		}
		require AC_DIR . 'includes/views/view-field-builder.php';
	}

	/**
	 * Contact Us page settings.
	 * @since 1.0.0
	 */
	public function render_contact_page_screen() {
		if ( ! current_user_can( ac_get_capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'advisers-contacts' ) );
		}
		require AC_DIR . 'includes/views/view-contact-page.php';
	}

	/**
	 * General plugin settings.
	 * @since 1.0.0
	 */
	public function render_settings_screen() {
		if ( ! current_user_can( ac_get_capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'advisers-contacts' ) );
		}
		require AC_DIR . 'includes/views/view-settings.php';
	}

	/* -----------------------------------------------------------------
	 * admin-post.php handlers (form posts with full page reload)
	 * -------------------------------------------------------------- */

	/**
	 * Change a single submission's status (approve/reject/pending).
	 * @since 1.0.0
	 */
	public function handle_change_status() {
		$this->guard();
		$id     = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$status = isset( $_POST['status'] ) ? sanitize_key( $_POST['status'] ) : '';

		if ( $id && in_array( $status, array( 'pending', 'approved', 'rejected' ), true ) ) {
			AC_DB::update_submission( $id, array( 'status' => $status ) );
		}

		$this->redirect_with_notice( wp_get_referer(), 'status_updated' );
	}

	/**
	 * Toggle the "important" flag.
	 * @since 1.0.0
	 */
	public function handle_toggle_important() {
		$this->guard();
		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;

		if ( $id ) {
			$submission = AC_DB::get_submission( $id );
			if ( $submission ) {
				AC_DB::update_submission( $id, array( 'is_important' => $submission->is_important ? 0 : 1 ) );
			}
		}

		$this->redirect_with_notice( wp_get_referer(), 'important_updated' );
	}

	/**
	 * Delete a submission.
	 * @since 1.0.0
	 */
	public function handle_delete_submission() {
		$this->guard();
		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;

		if ( $id ) {
			AC_DB::delete_submission( $id );
		}

		$url = admin_url( 'admin.php?page=advisers-contacts' );
		$this->redirect_with_notice( $url, 'deleted' );
	}

	/**
	 * Save edits made on the submission detail screen.
	 * @since 1.0.0
	 */
	public function handle_update_submission() {
		$this->guard();
		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		if ( ! $id ) {
			wp_die( esc_html__( 'Invalid submission.', 'advisers-contacts' ) );
		}

		$fields = AC_Fields::get_fields();
		$core   = array();
		$extra  = array();

		foreach ( $fields as $field ) {
			if ( in_array( $field->type, array( 'submit', 'file' ), true ) ) {
				continue;
			}
			$raw = isset( $_POST[ 'ac_field_' . $field->field_key ] ) ? wp_unslash( $_POST[ 'ac_field_' . $field->field_key ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$val = AC_Helpers::sanitize_field_value( $field->type, $raw );

			if ( in_array( $field->field_key, array( 'full_name', 'mobile_number', 'email', 'subject', 'referred_by' ), true ) ) {
				$core[ $field->field_key ] = $val;
			} else {
				$extra[ $field->field_key ] = $val;
			}
		}

		$existing               = AC_DB::get_submission( $id );
		$existing_extra         = $existing && $existing->field_data ? json_decode( $existing->field_data, true ) : array();
		$core['field_data']     = wp_json_encode( array_merge( (array) $existing_extra, $extra ) );

		AC_DB::update_submission( $id, $core );

		$url = admin_url( 'admin.php?page=ac-view-submission&id=' . $id );
		$this->redirect_with_notice( $url, 'saved' );
	}

	/**
	 * Bulk actions from the submissions list table.
	 * @since 1.0.0
	 */
	public function handle_bulk_action() {
		$this->guard();

		$ids    = isset( $_POST['ids'] ) ? array_map( 'absint', (array) $_POST['ids'] ) : array();
		$action = isset( $_POST['bulk_action'] ) ? sanitize_key( $_POST['bulk_action'] ) : '';

		foreach ( $ids as $id ) {
			switch ( $action ) {
				case 'approve':
					AC_DB::update_submission( $id, array( 'status' => 'approved' ) );
					break;
				case 'reject':
					AC_DB::update_submission( $id, array( 'status' => 'rejected' ) );
					break;
				case 'important':
					AC_DB::update_submission( $id, array( 'is_important' => 1 ) );
					break;
				case 'unimportant':
					AC_DB::update_submission( $id, array( 'is_important' => 0 ) );
					break;
				case 'delete':
					AC_DB::delete_submission( $id );
					break;
			}
		}

		$this->redirect_with_notice( wp_get_referer(), 'bulk_done' );
	}

	/**
	 * Save drag-drop order + enabled/required toggles from the field builder.
	 * @since 1.0.0
	 */
	public function handle_save_field_order() {
		$this->guard( 'ac_field_builder' );

		$rows = isset( $_POST['fields'] ) ? wp_unslash( $_POST['fields'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( is_string( $rows ) ) {
			$rows = json_decode( $rows, true );
		}

		if ( is_array( $rows ) ) {
			AC_Fields::save_order( $rows );
		}

		$url = admin_url( 'admin.php?page=ac-field-builder' );
		$this->redirect_with_notice( $url, 'fields_saved' );
	}

	/**
	 * Add a new custom field.
	 * @since 1.0.0
	 */
	public function handle_add_field() {
		$this->guard( 'ac_field_builder' );

		$result = AC_Fields::add_field(
			array(
				'label'       => isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : '',
				'type'        => isset( $_POST['type'] ) ? sanitize_key( $_POST['type'] ) : 'text',
				'options'     => isset( $_POST['options'] ) ? sanitize_textarea_field( wp_unslash( $_POST['options'] ) ) : '',
				'placeholder' => isset( $_POST['placeholder'] ) ? sanitize_text_field( wp_unslash( $_POST['placeholder'] ) ) : '',
				'required'    => ! empty( $_POST['required'] ),
			)
		);

		$url = admin_url( 'admin.php?page=ac-field-builder' );
		$this->redirect_with_notice( $url, is_wp_error( $result ) ? 'error' : 'field_added' );
	}

	/**
	 * Delete any field (default or custom) from the form.
	 * @since 1.0.0
	 */
	public function handle_delete_field() {
		$this->guard( 'ac_field_builder' );

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		AC_Fields::delete_field( $id );

		$url = admin_url( 'admin.php?page=ac-field-builder' );
		$this->redirect_with_notice( $url, 'field_deleted' );
	}

	/**
	 * Restore a previously deleted default field.
	 *
	 * @since 1.1.0
	 */
	public function handle_restore_field() {
		$this->guard( 'ac_field_builder' );

		$key    = isset( $_POST['field_key'] ) ? sanitize_key( $_POST['field_key'] ) : '';
		$result = $key ? AC_Fields::restore_field( $key ) : new WP_Error( 'ac_missing_key', __( 'Missing field key.', 'advisers-contacts' ) );

		$url = admin_url( 'admin.php?page=ac-field-builder' );
		$this->redirect_with_notice( $url, is_wp_error( $result ) ? 'error' : 'field_restored' );
	}

	/**
	 * Save Contact Us page settings.
	 * @since 1.0.0
	 */
	public function handle_save_page_settings() {
		$this->guard( 'ac_contact_page' );

		AC_Page::update_page(
			isset( $_POST['page_title'] ) ? sanitize_text_field( wp_unslash( $_POST['page_title'] ) ) : '',
			isset( $_POST['page_slug'] ) ? sanitize_title( wp_unslash( $_POST['page_slug'] ) ) : '',
			isset( $_POST['page_content'] ) ? wp_kses_post( wp_unslash( $_POST['page_content'] ) ) : ''
		);

		$url = admin_url( 'admin.php?page=ac-contact-page' );
		$this->redirect_with_notice( $url, 'page_saved' );
	}

	/**
	 * Save general settings.
	 * @since 1.0.0
	 */
	public function handle_save_general_settings() {
		$this->guard( 'ac_settings' );

		update_option( 'ac_default_country_code', isset( $_POST['default_country_code'] ) ? sanitize_text_field( wp_unslash( $_POST['default_country_code'] ) ) : '91' );
		update_option( 'ac_per_page', isset( $_POST['per_page'] ) ? max( 5, absint( $_POST['per_page'] ) ) : 20 );
		update_option( 'ac_notify_email', isset( $_POST['notify_email'] ) ? sanitize_email( wp_unslash( $_POST['notify_email'] ) ) : '' );

		$url = admin_url( 'admin.php?page=ac-settings' );
		$this->redirect_with_notice( $url, 'settings_saved' );
	}

	/* -----------------------------------------------------------------
	 * AJAX
	 * -------------------------------------------------------------- */

	/**
	 * Quick "mark important" star toggle from the list table, no reload.
	 * @since 1.0.0
	 */
	public function ajax_quick_toggle_important() {
		check_ajax_referer( 'ac_admin_ajax', 'nonce' );

		if ( ! current_user_can( ac_get_capability() ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'advisers-contacts' ) ), 403 );
		}

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$submission = $id ? AC_DB::get_submission( $id ) : null;

		if ( ! $submission ) {
			wp_send_json_error( array( 'message' => __( 'Submission not found.', 'advisers-contacts' ) ), 404 );
		}

		$new_value = $submission->is_important ? 0 : 1;
		AC_DB::update_submission( $id, array( 'is_important' => $new_value ) );

		wp_send_json_success( array( 'important' => (bool) $new_value ) );
	}

	/* -----------------------------------------------------------------
	 * Internal helpers
	 * -------------------------------------------------------------- */

	/**
	 * Capability + nonce guard used by every admin-post handler.
	 *
	 * @since 1.0.0
	 * @param string $action Nonce action; defaults to the list table's action.
	 */
	private function guard( $action = 'ac_submissions_action' ) {
		if ( ! current_user_can( ac_get_capability() ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'advisers-contacts' ) );
		}
		check_admin_referer( $action, '_ac_nonce' );
	}

	/**
	 * Redirect back to a wp-admin screen with a notice query arg.
	 *
	 * @since 1.0.0
	 * @param string $url    Target URL.
	 * @param string $notice Notice key.
	 */
	private function redirect_with_notice( $url, $notice ) {
		$url = $url ? $url : admin_url( 'admin.php?page=advisers-contacts' );
		wp_safe_redirect( add_query_arg( 'ac_notice', $notice, $url ) );
		exit;
	}
}
