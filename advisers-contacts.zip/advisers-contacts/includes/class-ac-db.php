<?php
/**
 * Database access layer for Advisers Contacts.
 *
 * @package Advisers_Contacts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AC_DB
 *
 * Owns the two custom tables used by the plugin and provides small,
 * prepared-statement wrappers around them. No business logic lives here.
 * @since 1.0.0
 */
class AC_DB {

	/** @var AC_DB|null */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @since 1.0.0
	 * @return AC_DB
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Submissions table name (prefixed).
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function submissions_table() {
		global $wpdb;
		return $wpdb->prefix . 'ac_submissions';
	}

	/**
	 * Fields table name (prefixed).
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function fields_table() {
		global $wpdb;
		return $wpdb->prefix . 'ac_fields';
	}

	/**
	 * Create/upgrade the plugin tables using dbDelta.
	 * @since 1.0.0
	 */
	public static function install() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();
		$submissions     = self::submissions_table();
		$fields          = self::fields_table();

		$sql_submissions = "CREATE TABLE {$submissions} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			full_name VARCHAR(191) NOT NULL DEFAULT '',
			mobile_number VARCHAR(32) NOT NULL DEFAULT '',
			email VARCHAR(191) NOT NULL DEFAULT '',
			subject VARCHAR(191) NOT NULL DEFAULT '',
			referred_by VARCHAR(191) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			is_important TINYINT(1) NOT NULL DEFAULT 0,
			field_data LONGTEXT NULL,
			attachment_ids VARCHAR(255) NOT NULL DEFAULT '',
			ip_address VARCHAR(100) NOT NULL DEFAULT '',
			user_agent VARCHAR(255) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY status (status),
			KEY referred_by (referred_by),
			KEY is_important (is_important),
			KEY created_at (created_at)
		) {$charset_collate};";

		$sql_fields = "CREATE TABLE {$fields} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			field_key VARCHAR(64) NOT NULL,
			label VARCHAR(191) NOT NULL DEFAULT '',
			type VARCHAR(20) NOT NULL DEFAULT 'text',
			options LONGTEXT NULL,
			placeholder VARCHAR(191) NOT NULL DEFAULT '',
			is_required TINYINT(1) NOT NULL DEFAULT 0,
			is_enabled TINYINT(1) NOT NULL DEFAULT 1,
			is_locked TINYINT(1) NOT NULL DEFAULT 0,
			sort_order INT NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY field_key (field_key)
		) {$charset_collate};";

		dbDelta( $sql_submissions );
		dbDelta( $sql_fields );
	}

	/**
	 * Insert a submission.
	 *
	 * @since 1.0.0
	 * @param array $data Column => value pairs (already sanitized by caller).
	 * @return int|false Inserted ID, or false on failure.
	 */
	public static function insert_submission( $data ) {
		global $wpdb;

		$defaults = array(
			'full_name'      => '',
			'mobile_number'  => '',
			'email'          => '',
			'subject'        => '',
			'referred_by'    => '',
			'status'         => 'pending',
			'is_important'   => 0,
			'field_data'     => wp_json_encode( array() ),
			'attachment_ids' => '',
			'ip_address'     => '',
			'user_agent'     => '',
		);

		$data                = wp_parse_args( $data, $defaults );
		$data['created_at']  = current_time( 'mysql' );
		$data['updated_at']  = current_time( 'mysql' );

		$inserted = $wpdb->insert( self::submissions_table(), $data );

		return $inserted ? (int) $wpdb->insert_id : false;
	}

	/**
	 * Update a submission by ID.
	 *
	 * @since 1.0.0
	 * @param int   $id   Submission ID.
	 * @param array $data Column => value pairs.
	 * @return int|false Number of rows updated, or false on failure.
	 */
	public static function update_submission( $id, $data ) {
		global $wpdb;

		$data['updated_at'] = current_time( 'mysql' );

		return $wpdb->update( self::submissions_table(), $data, array( 'id' => (int) $id ) );
	}

	/**
	 * Delete a submission by ID.
	 *
	 * @since 1.0.0
	 * @param int $id Submission ID.
	 * @return int|false
	 */
	public static function delete_submission( $id ) {
		global $wpdb;
		return $wpdb->delete( self::submissions_table(), array( 'id' => (int) $id ), array( '%d' ) );
	}

	/**
	 * Get one submission row.
	 *
	 * @since 1.0.0
	 * @param int $id Submission ID.
	 * @return object|null
	 */
	public static function get_submission( $id ) {
		global $wpdb;
		$table = self::submissions_table();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ) );
	}

	/**
	 * Query submissions with search/filter/pagination support.
	 *
	 * @since 1.0.0
	 * @param array $args {
	 *     @type string $search    Free-text search across name/email/mobile/subject/field_data.
	 *     @type string $status    pending|approved|rejected|'' (all).
	 *     @type string $referrer  Exact referrer name filter.
	 *     @type string $important '1'|'0'|'' (all).
	 *     @type string $date_from Y-m-d.
	 *     @type string $date_to   Y-m-d.
	 *     @type string $orderby   Column name.
	 *     @type string $order     ASC|DESC.
	 *     @type int    $per_page  Rows per page.
	 *     @type int    $paged     1-indexed page number.
	 * }
	 * @return array { items: object[], total: int }
	 */
	public static function query_submissions( $args = array() ) {
		global $wpdb;
		$table = self::submissions_table();

		$defaults = array(
			'search'    => '',
			'status'    => '',
			'referrer'  => '',
			'important' => '',
			'date_from' => '',
			'date_to'   => '',
			'orderby'   => 'created_at',
			'order'     => 'DESC',
			'per_page'  => 20,
			'paged'     => 1,
		);
		$args = wp_parse_args( $args, $defaults );

		$where  = array( '1=1' );
		$params = array();

		if ( '' !== $args['search'] ) {
			$like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$where[]  = '(full_name LIKE %s OR email LIKE %s OR mobile_number LIKE %s OR subject LIKE %s OR referred_by LIKE %s OR field_data LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		if ( '' !== $args['status'] ) {
			$where[]  = 'status = %s';
			$params[] = $args['status'];
		}

		if ( '' !== $args['referrer'] ) {
			$where[]  = 'referred_by = %s';
			$params[] = $args['referrer'];
		}

		if ( '' !== $args['important'] ) {
			$where[]  = 'is_important = %d';
			$params[] = (int) $args['important'];
		}

		if ( '' !== $args['date_from'] ) {
			$where[]  = 'created_at >= %s';
			$params[] = $args['date_from'] . ' 00:00:00';
		}

		if ( '' !== $args['date_to'] ) {
			$where[]  = 'created_at <= %s';
			$params[] = $args['date_to'] . ' 23:59:59';
		}

		$allowed_orderby = array( 'id', 'full_name', 'status', 'referred_by', 'created_at' );
		$orderby          = in_array( $args['orderby'], $allowed_orderby, true ) ? $args['orderby'] : 'created_at';
		$order            = 'ASC' === strtoupper( $args['order'] ) ? 'ASC' : 'DESC';

		$where_sql = implode( ' AND ', $where );

		$per_page = max( 1, (int) $args['per_page'] );
		$paged    = max( 1, (int) $args['paged'] );
		$offset   = ( $paged - 1 ) * $per_page;

		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
		$total     = $params ? (int) $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : (int) $wpdb->get_var( $count_sql );

		$data_sql       = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d";
		$data_params    = array_merge( $params, array( $per_page, $offset ) );
		$items          = $wpdb->get_results( $wpdb->prepare( $data_sql, $data_params ) );

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * Aggregate referrer stats: total / approved / rejected / pending counts
	 * per distinct, non-empty referred_by value.
	 *
	 * @since 1.0.0
	 * @return array[] List of assoc arrays: referrer, total, approved, rejected, pending.
	 */
	public static function get_referrer_stats() {
		global $wpdb;
		$table = self::submissions_table();

		$sql = "SELECT referred_by AS referrer,
					COUNT(*) AS total,
					SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved,
					SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected,
					SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending
				FROM {$table}
				WHERE referred_by IS NOT NULL AND referred_by <> ''
				GROUP BY referred_by
				ORDER BY total DESC";

		$results = $wpdb->get_results( $sql, ARRAY_A );

		return $results ? $results : array();
	}

	/**
	 * Count of distinct referrers with at least one submission.
	 *
	 * @since 1.0.0
	 * @return int
	 */
	public static function count_referrers() {
		global $wpdb;
		$table = self::submissions_table();
		return (int) $wpdb->get_var( "SELECT COUNT(DISTINCT referred_by) FROM {$table} WHERE referred_by IS NOT NULL AND referred_by <> ''" );
	}
}
