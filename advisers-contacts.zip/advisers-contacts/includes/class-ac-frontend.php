<?php
/**
 * Front-end shortcode and guest submission handling for Advisers Contacts.
 *
 * @package Advisers_Contacts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AC_Frontend
 * @since 1.0.0
 */
class AC_Frontend {

	/** @var AC_Frontend|null */
	private static $instance = null;

	/** Transient prefix used for guest flash (validation error) messages. */
	const FLASH_PREFIX = 'ac_flash_';

	/**
	 * Get singleton instance.
	 *
	 * @since 1.0.0
	 * @return AC_Frontend
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->hooks();
		}
		return self::$instance;
	}

	/**
	 * Register hooks.
	 * @since 1.0.0
	 */
	private function hooks() {
		add_shortcode( 'advisers_contact_form', array( $this, 'render_shortcode' ) );

		add_action( 'admin_post_ac_submit_contact_form', array( $this, 'handle_submission' ) );
		add_action( 'admin_post_nopriv_ac_submit_contact_form', array( $this, 'handle_submission' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Enqueue front-end styles, only on pages that carry the shortcode.
	 * @since 1.0.0
	 */
	public function enqueue_assets() {
		if ( ! is_singular() || ! has_shortcode( get_post()->post_content, 'advisers_contact_form' ) ) {
			return;
		}
		wp_enqueue_style( 'ac-frontend', AC_URL . 'assets/css/frontend.css', array(), AC_VERSION );
		wp_enqueue_script( 'ac-frontend', AC_URL . 'assets/js/frontend.js', array( 'jquery' ), AC_VERSION, true );
	}

	/**
	 * Render the [advisers_contact_form] shortcode.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public function render_shortcode() {
		$fields = AC_Fields::get_fields( true );

		$flash = $this->get_flash();

		ob_start();
		?>
		<div class="ac-form-wrap">
			<?php if ( ! empty( $flash['success'] ) ) : ?>
				<div class="ac-notice ac-notice-success"><?php echo esc_html( $flash['success'] ); ?></div>
			<?php endif; ?>

			<?php if ( ! empty( $flash['error'] ) ) : ?>
				<div class="ac-notice ac-notice-error"><?php echo esc_html( $flash['error'] ); ?></div>
			<?php endif; ?>

			<?php if ( empty( $flash['success'] ) ) : ?>
			<form class="ac-form" method="post" enctype="multipart/form-data"
				action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="ac_submit_contact_form" />
				<?php wp_nonce_field( 'ac_submit_contact_form', 'ac_nonce' ); ?>
				<p class="ac-hp-field" aria-hidden="true">
					<label for="ac_website">Website</label>
					<input type="text" id="ac_website" name="ac_website" tabindex="-1" autocomplete="off" />
				</p>

				<?php
				$has_submit = false;
				foreach ( $fields as $field ) {
					if ( 'submit' === $field->type ) {
						$has_submit = true;
					}
					$this->render_field( $field, isset( $flash['values'][ $field->field_key ] ) ? $flash['values'][ $field->field_key ] : '' );
				}
				?>

				<?php if ( ! $has_submit ) : ?>
					<p class="ac-field ac-field-submit"><button type="submit" class="ac-submit-btn"><?php esc_html_e( 'Submit', 'advisers-contacts' ); ?></button></p>
				<?php endif; ?>
			</form>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Render a single field row.
	 *
	 * @since 1.0.0
	 * @param object $field Field definition row.
	 * @param string $value Previously submitted value (repopulated on validation error).
	 */
	private function render_field( $field, $value = '' ) {
		if ( 'submit' === $field->type ) {
			echo '<p class="ac-field ac-field-submit"><button type="submit" class="ac-submit-btn">' . esc_html( $field->label ) . '</button></p>';
			return;
		}

		$name     = esc_attr( $field->field_key );
		$id       = 'ac-' . esc_attr( $field->field_key );
		$required = $field->is_required ? ' required' : '';
		$req_mark = $field->is_required ? ' <span class="ac-required">*</span>' : '';

		echo '<p class="ac-field ac-field-' . esc_attr( $field->type ) . '">';
		echo '<label for="' . esc_attr( $id ) . '">' . esc_html( $field->label ) . $req_mark . '</label>';

		switch ( $field->type ) {
			case 'textarea':
				echo '<textarea id="' . esc_attr( $id ) . '" name="' . $name . '" rows="4"' . $required . '>' . esc_textarea( $value ) . '</textarea>';
				break;

			case 'select':
				$options = $field->options ? json_decode( $field->options, true ) : array();
				echo '<select id="' . esc_attr( $id ) . '" name="' . $name . '"' . $required . '>';
				echo '<option value="">' . esc_html__( '— Select —', 'advisers-contacts' ) . '</option>';
				foreach ( (array) $options as $option ) {
					echo '<option value="' . esc_attr( $option ) . '" ' . selected( $value, $option, false ) . '>' . esc_html( $option ) . '</option>';
				}
				echo '</select>';
				break;

			case 'file':
				echo '<input type="file" id="' . esc_attr( $id ) . '" name="' . $name . '[]" multiple' . $required . ' />';
				break;

			case 'date':
				echo '<input type="date" id="' . esc_attr( $id ) . '" name="' . $name . '" value="' . esc_attr( $value ) . '"' . $required . ' />';
				break;

			case 'email':
			case 'tel':
			case 'url':
				echo '<input type="' . esc_attr( $field->type ) . '" id="' . esc_attr( $id ) . '" name="' . $name . '" value="' . esc_attr( $value ) . '" placeholder="' . esc_attr( $field->placeholder ) . '"' . $required . ' />';
				break;

			default:
				echo '<input type="text" id="' . esc_attr( $id ) . '" name="' . $name . '" value="' . esc_attr( $value ) . '" placeholder="' . esc_attr( $field->placeholder ) . '"' . $required . ' />';
				break;
		}

		echo '</p>';
	}

	/**
	 * Handle POST from the front-end form (guests and logged-in users).
	 * @since 1.0.0
	 */
	public function handle_submission() {
		if ( ! isset( $_POST['ac_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ac_nonce'] ) ), 'ac_submit_contact_form' ) ) {
			$this->fail( __( 'Security check failed. Please refresh the page and try again.', 'advisers-contacts' ) );
		}

		// Honeypot: a filled hidden field means a bot filled every input.
		if ( ! empty( $_POST['ac_website'] ) ) {
			$this->fail( __( 'Submission rejected.', 'advisers-contacts' ) );
		}

		if ( $this->is_rate_limited() ) {
			$this->fail( __( 'You are submitting too frequently. Please try again later.', 'advisers-contacts' ) );
		}

		$fields   = AC_Fields::get_fields( true );
		$values   = array();
		$errors   = array();
		$core     = array();
		$extra    = array();

		foreach ( $fields as $field ) {
			if ( 'submit' === $field->type ) {
				continue;
			}

			if ( 'file' === $field->type ) {
				continue; // Handled separately below.
			}

			$raw = isset( $_POST[ $field->field_key ] ) ? wp_unslash( $_POST[ $field->field_key ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$val = AC_Helpers::sanitize_field_value( $field->type, $raw );

			if ( $field->is_required && '' === $val ) {
				/* translators: %s: field label */
				$errors[] = sprintf( __( '%s is required.', 'advisers-contacts' ), $field->label );
			}

			if ( 'email' === $field->type && '' !== $val && ! is_email( $val ) ) {
				$errors[] = __( 'Please enter a valid email address.', 'advisers-contacts' );
			}

			$values[ $field->field_key ] = $val;

			if ( in_array( $field->field_key, array( 'full_name', 'mobile_number', 'email', 'subject', 'referred_by' ), true ) ) {
				$core[ $field->field_key ] = $val;
			} else {
				$extra[ $field->field_key ] = $val;
			}
		}

		if ( $errors ) {
			$this->fail( implode( ' ', $errors ), $values );
		}

		$attachment_ids = $this->handle_uploads();

		$data = array_merge(
			$core,
			array(
				'field_data'     => wp_json_encode( $extra ),
				'attachment_ids' => implode( ',', $attachment_ids ),
				'status'         => 'pending',
				'ip_address'     => $this->get_client_ip(),
				'user_agent'     => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
			)
		);

		$id = AC_DB::insert_submission( $data );

		if ( ! $id ) {
			$this->fail( __( 'Something went wrong while saving your submission. Please try again.', 'advisers-contacts' ), $values );
		}

		/**
		 * Fires after a contact form submission has been stored.
		 *
		 * @param int   $id   New submission ID.
		 * @param array $data Stored submission data.
		 */
		do_action( 'ac_after_submission', $id, $data );

		$this->set_flash( array( 'success' => __( 'Thank you — your message has been received.', 'advisers-contacts' ) ) );
		$this->redirect_back();
	}

	/**
	 * Move uploaded files into the Media Library and return their IDs.
	 *
	 * @since 1.0.0
	 * @return int[]
	 */
	private function handle_uploads() {
		if ( empty( $_FILES['upload_files'] ) ) {
			return array();
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$allowed_types = array( 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'pdf' => 'application/pdf', 'doc' => 'application/msword', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'xls' => 'application/vnd.ms-excel', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'zip' => 'application/zip' );
		$max_bytes     = (int) apply_filters( 'ac_max_upload_bytes', 5 * MB_IN_BYTES );

		$files = $_FILES['upload_files']; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$count = is_array( $files['name'] ) ? count( $files['name'] ) : 0;
		$ids   = array();

		for ( $i = 0; $i < $count; $i++ ) {
			if ( empty( $files['name'][ $i ] ) || UPLOAD_ERR_NO_FILE === $files['error'][ $i ] ) {
				continue;
			}
			if ( $files['size'][ $i ] > $max_bytes ) {
				continue;
			}

			$file = array(
				'name'     => $files['name'][ $i ],
				'type'     => $files['type'][ $i ],
				'tmp_name' => $files['tmp_name'][ $i ],
				'error'    => $files['error'][ $i ],
				'size'     => $files['size'][ $i ],
			);

			add_filter( 'upload_mimes', function () use ( $allowed_types ) {
				return $allowed_types;
			} );

			$overrides = array( 'test_form' => false );
			$results   = wp_handle_upload( $file, $overrides );

			remove_all_filters( 'upload_mimes' );

			if ( empty( $results['file'] ) ) {
				continue;
			}

			$attachment = array(
				'post_mime_type' => $results['type'],
				'post_title'     => sanitize_file_name( pathinfo( $results['file'], PATHINFO_FILENAME ) ),
				'post_status'    => 'inherit',
			);

			$attach_id = wp_insert_attachment( $attachment, $results['file'] );
			if ( ! is_wp_error( $attach_id ) && $attach_id ) {
				wp_update_attachment_metadata( $attach_id, wp_generate_attachment_metadata( $attach_id, $results['file'] ) );
				$ids[] = $attach_id;
			}
		}

		return $ids;
	}

	/**
	 * Simple per-IP submission rate limit (5/hour) to slow down abuse.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	private function is_rate_limited() {
		$key   = 'ac_rl_' . md5( $this->get_client_ip() );
		$count = (int) get_transient( $key );

		if ( $count >= 5 ) {
			return true;
		}

		set_transient( $key, $count + 1, HOUR_IN_SECONDS );
		return false;
	}

	/**
	 * Best-effort client IP lookup.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private function get_client_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return $ip;
	}

	/**
	 * Store a validation failure message + submitted values, then redirect
	 * back to the referring page so guests see inline errors.
	 *
	 * @since 1.0.0
	 * @param string $message Error message.
	 * @param array  $values  Previously entered values to repopulate.
	 */
	private function fail( $message, $values = array() ) {
		$this->set_flash( array(
			'error'  => $message,
			'values' => $values,
		) );
		$this->redirect_back();
	}

	/**
	 * Persist a flash message for this guest via a cookie-keyed transient.
	 *
	 * @since 1.0.0
	 * @param array $data Flash payload.
	 */
	private function set_flash( $data ) {
		$token = isset( $_COOKIE['ac_flash_token'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['ac_flash_token'] ) ) : '';
		if ( ! $token ) {
			$token = wp_generate_password( 20, false );
			setcookie( 'ac_flash_token', $token, time() + 60, COOKIEPATH ?: '/', COOKIE_DOMAIN );
		}
		set_transient( self::FLASH_PREFIX . $token, $data, MINUTE_IN_SECONDS );
	}

	/**
	 * Retrieve and clear this guest's flash message.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	private function get_flash() {
		$token = isset( $_COOKIE['ac_flash_token'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['ac_flash_token'] ) ) : '';
		if ( ! $token ) {
			return array();
		}
		$data = get_transient( self::FLASH_PREFIX . $token );
		delete_transient( self::FLASH_PREFIX . $token );
		return $data ? $data : array();
	}

	/**
	 * Redirect back to the page the form was submitted from.
	 * @since 1.0.0
	 */
	private function redirect_back() {
		$referer = wp_get_referer();
		wp_safe_redirect( $referer ? $referer : home_url( '/' ) );
		exit;
	}
}
